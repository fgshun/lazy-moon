# coding: utf-8

u"""
http://www.55555.to/index.htm 極－NTSOFT－55555
の拡張子判別DLL 「WINEX32.DLL」 の Python ラッパー

fgshun
『銀月の符号』 http://d.hatena.ne.jp/fgshun/
"""
import os
from ctypes import windll, WINFUNCTYPE
from ctypes import create_string_buffer, POINTER, Structure
from ctypes import c_int, c_char
from ctypes.wintypes import LPSTR, LPCSTR, DWORD

__all__ = [
        'get_info', 'get_extlist', 'ExInfo',
        'tExInfo',
        'WinExGetInfo', 'WinExGetVersion',
        'WinExGetExNumKind', 'WinExGetExNumPattern', 'WinExGetExtList',
        'WinExGetExtListLength', 'WinExGetFileCRC', 'WinExGetFileCRC32',
        'EX_MAX_BUFF',
        'BUFFSIZE_256', 'BUFFSIZE_512', 'BUFFSIZE_1000',
        'BUFFSIZE_2000', 'BUFFSIZE_3000', 'BUFFSIZE_6000', 'BUFFSIZE_12000',
        'BUFFSIZE_24000', 'BUFFSIZE_35000', 'BUFFSIZE_40000',
        'BUFFSIZE_50000',
        'DISTIN_NORMAL',  'DISTIN_MAC',  'DISTIN_FOOTER',
        'DISTIN_SPECIAL', 'DISTIN_NOMESSAGE',
        'WinEx32Error',]
__version__ = '0.1'
__date__ = '2009-01-10'

CharArray256 = c_char * 256
CharArray512 = c_char * 512

# 最大のバファサイズ
EX_MAX_BUFF = 40000

# 判別するバイト数
BUFFSIZE_256 = 256
BUFFSIZE_512 = 512
BUFFSIZE_1000 = 1000
BUFFSIZE_2000 = 2000
BUFFSIZE_3000 = 3000
BUFFSIZE_6000 = 6000
BUFFSIZE_12000 = 12000
BUFFSIZE_24000 = 24000
BUFFSIZE_35000 = 35000
BUFFSIZE_40000 = 40000
BUFFSIZE_50000 = 50000

# 判別方法
DISTIN_NORMAL = 0 # 普通に調べる
DISTIN_MAC = 1 # マックバイナリで調べる
DISTIN_FOOTER = 2 # フッター判別する
DISTIN_SPECIAL = 4 # 偽装系の特殊形式も判別、低速
DISTIN_NOMESSAGE = 8 # メッセージボックスを出さない
                     #（指定したファイルが見つかりません、など)

class WinEx32Error(Exception):
    pass

class tExInfo(Structure):
    _fields_ = [
            ('szFileEx', CharArray512),
            ('szExInfo1', CharArray256),
            ('szExInfo2', CharArray512),
            ]

class ExInfo(object):
    u"""get_info 関数にて返される拡張子判別結果

    属性:
      exts - 判別結果の拡張子のリスト
      info1 - 判別結果の簡単な説明
      info2 - 判別結果の付属情報
    """
    def __init__(self, t_exinfo):
        self.exts = t_exinfo.szFileEx.split(',')
        self.info1 = t_exinfo.szExInfo1
        self.info2 = t_exinfo.szExInfo2

try:
    _WinEx32 = windll.LoadLibrary(
            os.path.join(os.path.dirname(__file__), 'WinEx32'))
except WindowsError:
    _WinEx32 = windll.WinEx32

def _errcheck(result, func, args):
    if args[2].szFileEx == '?':
        raise WinEx32Error(u'判別できません')
    return args

# 拡張子を判別し構造体に情報を返す関数
_prototype = WINFUNCTYPE(c_int, LPCSTR, c_int, POINTER(tExInfo), DWORD)
_paramflags = (
        (1, 'pcszFileName'),
        (1, 'nBuffLen'),
        (2, 'data'),
        (1, 'dwFlag'),
        )
WinExGetInfo = _prototype(
        ('WinExGetInfo', _WinEx32), _paramflags)
WinExGetInfo.errcheck = _errcheck

# WinEx32.DLL のバージョンを返す
_prototype = WINFUNCTYPE(c_int)
_paramflags = ()
WinExGetVersion = _prototype(
        ('WinExGetVersion', _WinEx32), _paramflags)

# WinEx32.DLL が対応している拡張子の種類
_prototype = WINFUNCTYPE(c_int)
_paramflags = ()
WinExGetExNumKind = _prototype(
        ('WinExGetExNumKind', _WinEx32), _paramflags)

# WinEx32.DLL が対応している拡張子のパターン数
_prototype = WINFUNCTYPE(c_int)
_paramflags = ()
WinExGetExNumPattern = _prototype(
        ('WinExGetExNumPattern', _WinEx32), _paramflags)

# 対応している拡張子の一覧を CSV 形式で取得する
# 戻り値は拡張子数。WinExGetExNumKind, WinExGetExNumPattern とは異なる。
_prototype = WINFUNCTYPE(c_int, LPSTR)
_paramflags = ((1, 'szExList'),)
WinExGetExtList = _prototype(
        ('WinExGetExtList', _WinEx32), _paramflags)

# WinExGetExtList 関数で受け取るバッファサイズを返す
_prototype = WINFUNCTYPE(c_int)
_paramflags = ()
WinExGetExtListLength = _prototype(
        ('WinExGetExtListLength', _WinEx32), _paramflags)

# 指定したファイルの CRC(16bit)計算の値を返す
_prototype = WINFUNCTYPE(c_int, LPCSTR)
_paramflags = ((1, 'pcszFileName'),)
WinExGetFileCRC = _prototype(
        ('WinExGetFileCRC', _WinEx32), _paramflags)

# 指定したファイルの CRC(32bit)計算の値を返す
_prototype = WINFUNCTYPE(c_int, LPCSTR)
_paramflags = ((1, 'pcszFileName'),)
WinExGetFileCRC32 = _prototype(
        ('WinExGetFileCRC32', _WinEx32), _paramflags)

def get_extlist():
    u"""対応している拡張子の一覧をリストで返す
    """
    extcsv_length = WinExGetExtListLength()
    extcsv = create_string_buffer(extcsv_length)
    WinExGetExtList(extcsv)
    return extcsv.value.split(',')

def get_info(path, buffsize=BUFFSIZE_40000,
        distin=DISTIN_FOOTER|DISTIN_NOMESSAGE):
    u"""path の拡張子を判別する
    戻り値は ExInfo インスタンス。
    判別できなかったときは WinEx32Error 例外を送出する。
    """
    info = WinExGetInfo(path, buffsize, distin)
    return ExInfo(info)

def main():
    import sys
    for arg in sys.argv[1:]:
        print arg
        try:
            info = get_info(os.path.abspath(arg))
            print info.exts[0]
            print info.info1
            if info.info2:
                print info.info2
        except WinEx32Error, e:
            print e
        print

if __name__ == '__main__':
    main()
