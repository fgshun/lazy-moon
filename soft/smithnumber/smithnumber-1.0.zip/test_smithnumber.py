import unittest
import itertools
import functools

import smithnumber

# A006753
smith_numbers = (
        4,22,27,58,85,94,121,166,202,265,274,319,346,355,
        378,382,391,438,454,483,517,526,535,562,576,588,
        627,634,636,645,648,654,663,666,690,706,728,729,
        762,778,825,852,861,895,913,915,922,958,985,1086)

k_smith_numbers = {
        # A104390
        (2, 1): (
            32,42,60,70,104,152,231,315,316,322,330,342,361,
            406,430,450,540,602,610,612,632,703,722,812,1016,
            1027,1029,1108,1162,1190,1246,1261,1304,1314,1316,
            1351,1406,1470,1510,1603,2013,2054,2065,2070,2071,
            2106,2114),
        # A104391
        (3, 1): (
            402,510,700,1113,1131,1311,2006,2022,2130,2211,
            2240,3102,3111,3204,3210,3220,4031,4300,4410,5310,
            6004,6100,6300,7031,7120,9000,10034,10125,10206,
            10251,10304,10413,10521,10612,10800,11033,11111,
            11114),
        # A103125
        (4, 1): (
            2401,5010,7000,10005,10311,10410,10411,11060,
            11102,11203,12103,13002,13021,13101,14001,14101,
            14210,20022,20121,20203,20401,21103,21112,21120,
            21201,22040,22101,22201,23030,30003,30031,30320,
            31002,31101),
        # A103126
        (5, 1): (
            2030,10203,12110,20210,20310,21004,21010,24000,
            24010,31010,41001,50010,70000,100004,100012,
            100210,100310,100320,101020,101041,102022,103200,
            104010,104101,104110,105020,106001,110020,110202,
            110212,110400,111013),
        # A050224
        (1, 2): (
            88,169,286,484,598,682,808,844,897,961,1339,1573,
            1599,1878,1986,2266,2488,2626,2662,2743,2938,3193,
            3289,3751,3887,4084,4444,4642,4738,4804,4972,4976,
            4983,5566,5665,5764,5797,5863),
        # A050225
        (1, 3): (
            6969,19998,36399,39693,66099,69663,69897,89769,
            99363,99759,109989,118899,181998,191799,199089,
            297099,306939,333399,336963,339933,363099,396363,
            397998,399333,399729,588969,606666,606909,639633,
            660693,666633),
        # A103123
        (1, 4): (
            19899699,36969999,36999699,39699969,39999399,
            39999993,66699699,66798798,67967799,67987986,
            69759897,69889389,69966699,69996993,76668999,
            79488798,79866798,85994799,86686886,89769759,
            89866568),
        # A103124
        (1, 5): (
            399996663,666609999,669969663,690696969, 699966663),
        }

# A098837
smith_semiprimes = (
        4,22,58,85,94,121,166,202,265,274,319,346,355,
        382,391,454,517,526,535,562,634,706,778,895,913,
        922,958,985,1111,1165,1219,1255,1282,1507,1633,
        1642,1678,1795,1822,1858,1894,1903,1921,1966,2038,
        2155,2173,2182,2218)

# A098834
palindromic_smith_numbers = (
        4,22,121,202,454,535,636,666,1111,1881,3663,7227,
        7447,9229,10201,17271,22522,24142,28182,33633,
        38283,45054,45454,46664,47074,50305,51115,51315,
        54645,55055,55955,72627,81418,82628,83038,83938,
        90409,95359)

# A104171
reversible_smith_numbers = (
        4,22,58,85,121,202,265,319,454,535,562,636,666,
        913,1111,1507,1642,1881,1894,1903,2461,2583,2605,
        2614,2839,3091,3663,3852,4162,4198,4369,4594,4765,
        4788,4794,4954,4974,4981,5062,5386,5458,5539,5674,
        5818,5926)

# http://www.shyamsundergupta.com/smith.htm
fibonacci_smith_numbers = (
        1346269,5527939700884757,
        844617150046923109759866426342507997914076076194,
        )

# A098835
abundant_smith_numbers = (
        378,438,576,588,636,648,654,666,690,728,762,852,
        1086,1284,1376,1626,1736,1776,1842,1872,1908,1952,
        1962,2286,2484,2556,2576,2688,2934,2944,2958,2964,
        2970,3138,3168,3174,3246,3258,3294,3366,3390,3564,
        3690,3852)

# A098836
deficient_smith_numbers = (
        4,22,27,58,85,94,121,166,202,265,274,319,346,355,
        382,391,454,483,517,526,535,562,627,634,645,663,
        706,729,778,825,861,895,913,915,922,958,985,1111,
        1165,1219,1255,1282,1449,1507,1581,1633,1642,1678,
        1755,1795)

# A098839
smith_square_numbers = (
        4,121,576,729,6084,10201,17424,18496,36481,51529,
        100489,124609,184041,195364,410881,559504,674041,
        695556,732736,887364,896809,966289,988036,1038361,
        1190281,1238769,1726596,1852321,2166784,2975625,
        3407716)

# A098838
smith_cubic_numbers = (
        27,729,19683,474552,7077888,7414875,8489664,
        62099136,112678587,236029032,246491883,257259456,
        279726264,345948408,463684824,567663552,638277381,
        721734273,766060875,988047936,1177583616,
        1412467848)

# A098840
smith_trianglar_numbers = (
        378,666,861,2556,5253,7503,10296,16653,27261,
        28920,29890,32896,46056,72771,84255,85905,92235,
        94395,120786,132870,141778,157641,215496,328455,
        345696,385881,386760,396495,424581,529935,533028,
        588070,654940)

# A104166
repdigit_smith_numbers = (
        4,22,666,1111,6666666,4444444444,
        44444444444444444444,555555555555555555555555555,
        55555555555555555555555555555555,
        4444444444444444444444444444444444444444444444444444444,
        )

consecutive_smith_numbers = {
    # A50219
    2: (
        728,2964,3864,4959,5935,6187,9386,9633,11695,
        13764,16536,16591,20784,25428,28808,29623,32696,
        33632,35805,39585,43736,44733,49027,55344,56336,
        57663,58305,62634,65912,65974,66650,67067,67728,
        69279,69835),
    # A105648
    3: (
        73615,209065,225951,283745,305455,342879,656743,
        683670,729066,747948,774858,879221,954590),
    # A105649
    4: (
        4463535,6356910,8188933,9425550,11148564,
        15966114,18542654,21673542,22821992,23767287,
        28605144,36615667,39227466,47096634,47395362,
        48072396,54054264,55464835,57484614,57756450,
        57761165,58418508),
    # A105650
    5: (
        15966114,75457380,162449165,296049306,296861735,
        334792990,429619207,581097690,581519244,582548088,
        683474015,809079150,971285861,977218716),
    }

class Testsmithnumber(unittest.TestCase):
    def setUp(self):
        self.limit = 100000

    def all(self, nums1, nums2):
        limit = self.limit
        predicate = lambda x: x < limit
        return all(
                a ==  b for a, b in itertools.izip(
                    itertools.takewhile(predicate, nums1),
                    nums2))
                    #itertools.takewhile(predicate, nums2)))

    def test_smith_numbers(self):
        self.assert_(self.all(
            smith_numbers,
            smithnumber.smith_numbers()))

    def test_k_smith_numbers(self):
        for k, nums in k_smith_numbers.iteritems():
            self.assert_(self.all(
                nums,
                smithnumber.k_smith_numbers(k)))

    def test_smith_semiprimes(self):
        self.assert_(self.all(
            smith_semiprimes,
            smithnumber.smith_semiprimes()))

    def test_palindromic_smith_numbers(self):
        self.assert_(self.all(
            palindromic_smith_numbers,
            smithnumber.palindromic_smith_numbers()))

    def test_reversible_smith_numbers(self):
        self.assert_(self.all(
            reversible_smith_numbers,
            smithnumber.reversible_smith_numbers()))

    def test_fibonacci_smith_numbers(self):
        self.assert_(self.all(
            fibonacci_smith_numbers,
            smithnumber.fibonacci_smith_numbers()))

    def test_abundant_smith_numbers(self):
        self.assert_(self.all(
            abundant_smith_numbers,
            smithnumber.abundant_smith_numbers()))

    def test_deficient_smith_numbers(self):
        self.assert_(self.all(
            deficient_smith_numbers,
            smithnumber.deficient_smith_numbers()))

    def test_smith_square_numbers(self):
        self.assert_(self.all(
            smith_square_numbers,
            smithnumber.smith_square_numbers()))

    def test_smith_cubic_numbers(self):
        self.assert_(self.all(
            smith_cubic_numbers,
            smithnumber.smith_cubic_numbers()))

    def test_smith_trianglar_numbers(self):
        self.assert_(self.all(
            smith_trianglar_numbers,
            smithnumber.smith_trianglar_numbers()))

    def test_repdigit_smith_numbers(self):
        self.assert_(self.all(
            repdigit_smith_numbers,
            smithnumber.repdigit_smith_numbers()))

    def test_consecutive_smith_numbers(self):
        for k, nums in consecutive_smith_numbers.iteritems():
            self.assert_(self.all(
                nums,
                (x[0] for x in smithnumber.consecutive_smith_numbers(k))))

    def test_smallest_of_consecutive_smith_numbers(self):
        for k, nums in consecutive_smith_numbers.iteritems():
            self.assert_(self.all(
                nums,
                smithnumber.smallest_of_consecutive_smith_numbers(k)))

    def test_largest_of_consecutive_smith_numbers(self):
        for k, nums in consecutive_smith_numbers.iteritems():
            self.assert_(self.all(
                (n + k - 1 for n in nums),
                smithnumber.largest_of_consecutive_smith_numbers(k)))

class TestIssmithnumber(unittest.TestCase):
    def setUp(self):
        self.limit = 100000

    def all(self, predicate, seq):
        max_num = min(seq[-1], self.limit)
        return all(
                (num in seq) is predicate(num)
                for num in itertools.takewhile(
                    lambda x: x <= max_num, itertools.count(1)))

    def test_is_smith_numbers(self):
        self.assert_(self.all(
            smithnumber.is_smith_number,
            smith_numbers))

    def test_is_k_smith_numbers(self):
        for k, nums in k_smith_numbers.iteritems():
            self.assert_(self.all(
                functools.partial(smithnumber.is_k_smith_number, k=k),
                nums))

    def test_is_smith_semiprimes(self):
        self.assert_(self.all(
            smithnumber.is_smith_semiprimes,
            smith_semiprimes))

    def test_is_palindromic_smith_numbers(self):
        self.assert_(self.all(
            smithnumber.is_palindromic_smith_number,
            palindromic_smith_numbers))

    def test_is_reversible_smith_numbers(self):
        self.assert_(self.all(
            smithnumber.is_reversible_smith_number,
            reversible_smith_numbers))

    def test_is_fibonacci_smith_numbers(self):
        self.assert_(self.all(
            smithnumber.is_fibonacci_smith_number,
            fibonacci_smith_numbers))

    def test_is_abundant_smith_numbers(self):
        self.assert_(self.all(
            smithnumber.is_abundant_smith_number,
            abundant_smith_numbers))

    def test_is_deficient_smith_numbers(self):
        self.assert_(self.all(
            smithnumber.is_deficient_smith_number,
            deficient_smith_numbers))

    def test_is_smith_square_numbers(self):
        self.assert_(self.all(
            smithnumber.is_smith_square_number,
            smith_square_numbers))

    def test_is_smith_cubic_numbers(self):
        self.assert_(self.all(
            smithnumber.is_smith_cubic_number,
            smith_cubic_numbers))

    def test_is_smith_trianglar_numbers(self):
        self.assert_(self.all(
            smithnumber.is_smith_trianglar_number,
            smith_trianglar_numbers))

    def test_is_repdigit_smith_numbers(self):
        self.assert_(self.all(
            smithnumber.is_repdigit_smith_number,
            repdigit_smith_numbers))

if __name__ == '__main__':
    unittest.main()
