# coding: utf-8

u"""スミス数

スミス数（Smith number）とは、
数字の和 S(N) が素因子の数字の和 Sp(N) に等しい
合成数 N のことである。

例えば S(85)=8+5=13 であり、 Sp(85)=Sp(5*17)=5+1+7=13 であるため
85 はスミス数である。

最小のスミス数は 4 である。
1000 以下のスミス数は 49 個ある。

    4, 22, 27, 58, 85, 94, 121, 166, 202, 265,
    274, 319, 346, 355, 378, 382, 391, 438, 454, 483,
    517, 526, 535, 562, 576, 588, 627, 634, 636, 645,
    648, 654, 663, 666, 690, 706, 728, 729, 762, 778,
    825, 852, 861, 895, 913, 915, 922, 958, 985

1000000 以下のスミス数は 29928 個ある。

スミス数は によって名づけられた。
名前の由来は、命名者 Albert Wilansky 義理の兄 Harold Smith の
電話番号 4937775 がこの性質を持つこと。

    Sp(4937775)=Sp(3*5*5*65837)=3+5+5+6+5+8+3+7=42
    S(4937775)=4+9+3+7+7+7+5=42



作成
    fgshun (http://www.lazy-moon.jp/)

参考
    http://www.shyamsundergupta.com/smith.htm
    http://ja.wikipedia.org/wiki/%E3%82%B9%E3%83%9F%E3%82%B9%E6%95%B0



使用例1

スミス数の列を得るには smith_numbers を用いる。
smith_numbers は無限長のイテレータであるため、 for 文で用いるときには
終了条件をつける必要がある。たとえば、次のようにする。

>>> for n in smith_numbers():
...   if n > 30:
...     break
...   n
...
4
22
27

もしくは、次のようにする。

>>> from itertools import takewhile
>>> from smithnumber import smith_numbers
>>> list(takewhile(lambda x: x < 300, smith_numbers()))
[4, 22, 27, 58, 85, 94, 121, 166, 202, 265, 274]



使用例2

ある数がスミス数かどうかを確認するには is_smith_number を用いる。

>>> from smithnumber import is_smith_number
>>> is_smith_number(3)
False
>>> is_smith_number(4)
True
"""

from __future__ import division
import sys
import math
import itertools
import operator

__all__ = [
        'smith_numbers', 'k_smith_numbers', 'smith_semiprimes',
        'palindromic_smith_numbers', 'reversible_smith_numbers',
        'fibonacci_smith_numbers',
        'abundant_smith_numbers', 'deficient_smith_numbers',
        'smith_square_numbers', 'smith_cubic_numbers',
        'smith_trianglar_numbers', 'repdigit_smith_numbers',
        'consecutive_smith_numbers',
        'smallest_of_consecutive_smith_numbers',
        'largest_of_consecutive_smith_numbers',
        'smith_brothers',
        'smaller_of_smith_brothers', 'larger_of_smith_brothers',
        'smith_triples',
        'smallest_of_smith_triples', 'largest_of_smith_triples',
        'smith_quads', 'smith_quints',
        'is_smith_number', 'is_k_smith_number', 'is_smith_semiprimes',
        'is_palindromic_smith_number', 'is_reversible_smith_number',
        'is_fibonacci_smith_number',
        'is_abundant_smith_number', 'is_deficient_smith_number',
        'is_smith_square_number', 'is_smith_cubic_number',
        'is_smith_trianglar_number', 'is_repdigit_smith_number',
        'is_smallest_of_consecutive_smith_number',
        'is_largest_of_consecutive_smith_number']

version = '1.0.2'
version_info = (1, 0, 2)

if sys.version_info[:2] < (2, 5):
    def all(iterable):
        for element in iterable:
            if not element:
                return False
        return True

    def any(iterable):
        for element in iterable:
            if element:
                return True
        return False

    def partial(func, *args, **keywords):
        def newfunc(*fargs, **fkeywords):
            newkeywords = keywords.copy()
            newkeywords.update(fkeywords)
            return func(*(args + fargs), **newkeywords)
        newfunc.func = func
        newfunc.args = args
        newfunc.keywords = keywords
        return newfunc
else:
    from functools import partial

if sys.version_info[:2] < (2, 6):
    def next(iterator, *default):
        if len(default) > 2:
            raise TypeError(
                    'next() expected at most 2 arguments, got %d'
                    % len(default) + 1)
        try:
            return iterator.next()
        except StopIteration, e:
            if len(default):
                return default[0]
            raise

    def count(n=0):
        while True:
            yield n
            n += 1

    def enumerate(iterable, start=0):
        return itertools.izip(count(start), iterable)

else:
    from itertools import count
    from functools import reduce

def setwise(iterable, n=2):
    u"""s -> (s0,s1, ...), (s1,s2,...), (s2,s3,...), ..."""

    its = itertools.tee(iterable, n)
    for i, it in enumerate(its):
        for _ in itertools.imap(next, itertools.repeat(it, i)):
            pass
    return itertools.izip(*its)

def digits(n):
    u"""n をなす数字を返す

    >>> list(digits(123))
    [3, 2, 1]
    """

    while n > 0:
        n, m = divmod(n, 10)
        yield m

def reversible_number(n):
    u"""n を反転させた数字を返す"""

    r = 0
    for d in digits(n):
        r = r * 10 + d
    return r

def _ifactorize_p():
    u"""2, 3, および素数の可能性がある奇数 p = 6 * n ± 1"""

    yield 2
    yield 3
    num = 1
    for add in itertools.cycle((4, 2)):
        num += add
        yield num

def ifactorize(num):
    u"""素因数分解
    
    素因数を小さい順に一つずつ返すイテレータ。"""

    num = int(num)
    if num < 1:
        raise ValueError(u'%d is not positive number' % num)
    elif num == 1:
        yield 1
        return

    for fact in _ifactorize_p():
        if num < fact ** 2:
            if num > 1:
                yield num
            break
        q, r = divmod(num, fact)
        while not r:
            num = q
            yield fact
            q, r = divmod(num, fact)

def factorize(num):
    u"""素因数分解
    
    素因数をまとめた tuple を返す
    
    >>> factorize(360)
    (2, 2, 2, 3, 3, 5)
    """

    return tuple(ifactorize(num))

def fibonacci_numbers():
    u"""フィボナッチ数列"""

    a = 0
    b = 1
    yield a
    yield b
    while True:
        a, b = b, a + b
        yield b

def square_numbers():
    u"""平方数"""

    return (n ** 2 for n in count(1))

def cubic_numbers():
    u"""立方数"""

    return (n ** 3 for n in count(1))

def trianglar_numbers():
    u"""三角数"""

    return (n * (n + 1) // 2 for n in count(1))

def _divisor_function_s(x, prime_factor):
    for prime, g in itertools.groupby(prime_factor):
        a = 1
        b = 1
        for _ in g:
            b *= prime ** x
            a += b
        yield a

def divisor_function(n, x=1, prime_factor=None):
    u"""約数関数
    
    prime_factor 引数は n の素因数分解を事前に終えているときに
    その結果を渡すことで再度の素因数分解を防ぐためのもの"""

    if prime_factor is None:
        prime_factor = ifactorize(n)

    return reduce(
            operator.mul, _divisor_function_s(x, prime_factor))

def repdigit_numbers():
    u"""すべてが同じ数字の数"""

    d = (1, 2, 3, 4, 5, 6, 7, 8, 9)
    for i in count(1):
        for j in d:
            n = 0
            for x in xrange(i):
                n = n * 10 + j
            yield n

def is_palindromic_number(n):
    u"""n が回文数であるかどうか判定する"""

    d = tuple(digits(n))
    le = len(d)
    return all(a == b for a, b in zip(d[:le], d[:-le:-1]))

def is_fibonacci_number(n):
    u"""n がフィボナッチ数であるかどうか判定する"""

    return any(i == n for i in itertools.takewhile(
        lambda x: x <= n, fibonacci_numbers()))

def is_abundant_number(n, prime_factor=None):
    u"""n が過剰数であるかどうか判定する

    prime_factor 引数は n の素因数分解を事前に終えているときに
    その結果を渡すことで再度の素因数分解を防ぐためのもの"""

    return divisor_function(n, prime_factor=prime_factor) > n * 2

def is_deficient_number(n, prime_factor=None):
    u"""n が不足数であるかどうか判定する

    prime_factor 引数は n の素因数分解を事前に終えているときに
    その結果を渡すことで再度の素因数分解を防ぐためのもの"""

    return divisor_function(n, prime_factor=prime_factor) < n * 2

def is_square_number(n, prime_factor=None):
    u"""n が平方数であるかどうか判定する

    prime_factor 引数は n の素因数分解を事前に終えているときに
    その結果を渡すことで再度の素因数分解を防ぐためのもの"""

    if prime_factor is None:
        prime_factor = ifactorize(n)
    for k, g in itertools.groupby(prime_factor):
        for c, x in enumerate(g, 1):
            pass
        if c % 2:
            return False
    else:
        return True

def is_cubic_number(n, prime_factor=None):
    u"""n が立方数であるかどうか判定する

    prime_factor 引数は n の素因数分解を事前に終えているときに
    その結果を渡すことで再度の素因数分解を防ぐためのもの"""

    if prime_factor is None:
        prime_factor = ifactorize(n)
    for k, g in itertools.groupby(prime_factor):
        for c, x in enumerate(g, 1):
            pass
        if c % 3:
            return False
    else:
        return True

def is_trianglar_number(n):
    u"""n が三角数であるかどうか判定する"""

    return not math.modf(((math.sqrt(8 * n + 1) - 1) / 2))[0]

def is_repdigit_number(n):
    u"""n のすべての数字が等しいかどうか判定する"""

    d = digits(n)
    i = next(d)
    return all(i == j for j in d)

def is_consecutive_numbers(nums):
    u"""nums が連続した数字の組であるかどうか判定する"""

    it = iter(nums)
    num = next(it)
    return all(
            itertools.starmap(
                operator.eq,
                itertools.izip(it, count(num + 1))))

def is_smith_number(n, prime_factor=None):
    u"""n がスミス数であるかどうか判定する

    prime_factor 引数は n の素因数分解を事前に終えているときに
    その結果を渡すことで再度の素因数分解を防ぐためのもの"""

    if prime_factor is None:
        prime_factor = ifactorize(n)
    prime_factor = tuple(prime_factor)
    if len(prime_factor) == 1:
        return False
    a = sum(sum(digits(prime)) for prime in prime_factor)
    b = sum(digits(n))
    return a == b

def is_k_smith_number(n, k=(1, 1), prime_factor=None):
    u"""n が k-スミス数であるかどうか判定する

    prime_factor 引数は n の素因数分解を事前に終えているときに
    その結果を渡すことで再度の素因数分解を防ぐためのもの"""

    if prime_factor is None:
        prime_factor = ifactorize(n)
    prime_factor = tuple(prime_factor)
    if len(prime_factor) == 1:
        return False
    a = sum(sum(digits(prime)) for prime in prime_factor) * k[1]
    b = sum(digits(n)) * k[0]
    return a == b

def is_smith_semiprimes(n, prime_factor=None):
    u"""n が Smith Semiprimes であるかどうか判定する

    prime_factor 引数は n の素因数分解を事前に終えているときに
    その結果を渡すことで再度の素因数分解を防ぐためのもの"""

    if prime_factor is None:
        prime_factor = ifactorize(n)
    prime_factor = tuple(prime_factor)
    if len(prime_factor) != 2:
        return False
    a = sum(sum(digits(prime)) for prime in prime_factor)
    b = sum(digits(n))
    return a == b

def is_palindromic_smith_number(n):
    u"""n が Palindromic Smith Number であるかどうか判定する"""

    return is_palindromic_number(n) and is_smith_number(n)

def is_reversible_smith_number(n):
    u"""n が Reversible Smith Number であるかどうか判定する"""

    return is_smith_number(n) and is_smith_number(reversible_number(n))

def is_fibonacci_smith_number(n):
    u"""n が Fibonacci Smith Number であるかどうか判定する"""
    return is_fibonacci_number(n) and is_smith_number(n)

def is_abundant_smith_number(n):
    u"""n が Abundant Smith Number であるかどうか判定する"""

    prime_factor = factorize(n)
    return is_smith_number(n, prime_factor) and \
           is_abundant_number(n, prime_factor)

def is_deficient_smith_number(n):
    u"""n が Deficient Smith Number であるかどうか判定する"""

    prime_factor = factorize(n)
    return is_smith_number(n, prime_factor) and \
           is_deficient_number(n, prime_factor)

def is_smith_square_number(n):
    u"""n が Smith Square Number かどうか判定する"""

    prime_factors = itertools.tee(ifactorize(n))
    return is_square_number(n, prime_factors[0]) and \
           is_smith_number(n, prime_factors[1])

def is_smith_cubic_number(n):
    u"""n が Smith Cubic Number かどうか判定する"""

    prime_factors = itertools.tee(ifactorize(n))
    return is_cubic_number(n, prime_factors[0]) and \
           is_smith_number(n, prime_factors[1])

def is_smith_trianglar_number(n):
    u"""n が Smith Trianglar Number かどうか判定する"""

    return is_trianglar_number(n) and is_smith_number(n)

def is_repdigit_smith_number(n):
    u"""n が Smith Repdigit Number かどうか判定する"""

    return is_repdigit_number(n) and is_smith_number(n)

def is_smallest_of_consecutive_smith_number(n, r):
    u"""n が Consecutive Smith Numbers の組の最小値かどうか判定する"""

    return any(i == n for i in itertools.takewhile(
        lambda x: x <= n, smallest_of_consecutive_smith_numbers(r)))

def is_largest_of_consecutive_smith_number(n, r):
    u"""n が Consecutive Smith Numbers の組の最大値かどうか判定する"""

    return any(i == n for i in itertools.takewhile(
        lambda x: x <= n, largest_of_consecutive_smith_numbers(r)))

def smith_numbers():
    u"""スミス数

    スミス数とは数字の和と素因子の数字の和が等しい合成数である。
    """

    return itertools.ifilter(is_smith_number, count(4))

def k_smith_numbers(k=(1, 1)):
    u"""k-スミス数

    k-スミス数とは数字の和と素因子の数字の和の k 倍が等しい合成数である。

    引数は k をあらわす分子と分母のタプルである。
    """

    return itertools.ifilter(
            partial(is_k_smith_number, k=k), count(4))

def smith_semiprimes():
    u"""Smith Semiprimes

    Smith Semiprime とは 2 つの素因数からなるスミス数である。
    """

    return itertools.ifilter(is_smith_semiprimes, count(4))

def palindromic_smith_numbers():
    u"""Palindromic Smith Numbers

    Palindromic Smith Number とは回文数でもあるスミス数である。
    """

    return itertools.ifilter(
            is_palindromic_smith_number, count(4))

def reversible_smith_numbers():
    u"""Reversible Smith Numbers

    Reversible Smith Number は反転させてもスミス数であるスミス数である。
    """

    return itertools.ifilter(
            is_reversible_smith_number, count(4))

def fibonacci_smith_numbers():
    u"""Fibonacci Smith Numbers

    Fibonacci Smith Number とはフィボナッチ数でもあるスミス数である

    注意:
        Fibonacci Smith Number はすぐに値が大きくなるため
        このコードは実用に耐えられない。
        作者環境では 3 つめの値である
        844617150046923109759866426342507997914076076194
        を算出することはできなかった。
    """

    fib = fibonacci_numbers()
    next(fib)
    return itertools.ifilter(is_smith_number, fib)

def abundant_smith_numbers():
    u"""Abundant Smith Numbers

    Abundant Smith Number は過剰数でもあるスミス数である
    """

    return itertools.ifilter(is_abundant_smith_number, count(4))

def deficient_smith_numbers():
    u"""Deficient Smith Numbers

    Deficient Smith Number は不足数でもあるスミス数である
    """

    return itertools.ifilter(is_deficient_smith_number, count(4))
def smith_square_numbers():
    u"""Smith Square Numbers

    Smith Square Number は平方数でもあるスミス数である。
    """

    return itertools.ifilter(is_smith_number, square_numbers())

def smith_cubic_numbers():
    u"""Smith Cubic Numbers

    Smith Cubic Number は立方数でもあるスミス数である。
    """

    return itertools.ifilter(is_smith_number, cubic_numbers())

def smith_trianglar_numbers():
    u"""Smith Trianglar Numbers

    Smith Trianglar Numbers とは三角数でもあるスミス数である
    """

    return itertools.ifilter(is_smith_number, trianglar_numbers())

def repdigit_smith_numbers():
    u"""Repdigit Smith Numbers

    Repdigit Smith Number はすべての数字が等しいスミス数である

    注意:
        Repdigit Smith Number はすぐに値が大きくなるため
        このコードは実用に耐えられない。
        作者環境では 7 つめの値である
        44444444444444444444 を算出することはできなかった。
    """

    return itertools.ifilter(is_smith_number, repdigit_numbers())

def consecutive_smith_numbers(r):
    u"""Consecutive Smith Number

    Consecutive Smith Numbers は連続するスミス数の組である

    引数は何連続しているか示す値である。
    """

    return itertools.ifilter(
            is_consecutive_numbers, setwise(smith_numbers(), r))

def smallest_of_consecutive_smith_numbers(r):
    u"""Consecutive Smith Number の各組の最小値の列"""

    return itertools.imap(
            operator.itemgetter(0), consecutive_smith_numbers(r))

def largest_of_consecutive_smith_numbers(r):
    u"""Consecutive Smith Number の各組の最大値の列"""

    return itertools.imap(
            operator.itemgetter(-1), consecutive_smith_numbers(r))

def smith_brothers():
    u"""Smith Brothers

    Smith Brothers は 2 連続するスミス数の組である
    """

    return consecutive_smith_numbers(2)

def smaller_of_smith_brothers():

    return smallest_of_consecutive_smith_numbers(2)

def larger_of_smith_brothers():

    return largest_of_consecutive_smith_numbers(2)

def smith_triples():
    u"""Smith Triples

    Smith Triples は 3 連続するスミス数の組である
    """

    return consecutive_smith_numbers(3)

def smallest_of_smith_triples():

    return smallest_of_consecutive_smith_numbers(3)

def largest_of_smith_triples():

    return largest_of_consecutive_smith_numbers(3)

def smith_quads():
    u"""Smith Quads

    Smith Quads は 4 連続するスミス数の組である

    注意:
        Smith Quads はすぐに値が大きくなるため
        このコードは実用に耐えられない。
    """

    return consecutive_smith_numbers(4)

def smith_quints():
    u"""Smith Quints

    Smith Quads は 5 連続するスミス数の組である

    注意:
        Smith Quints はすぐに値が大きくなるため
        このコードは実用に耐えられない。
    """

    return consecutive_smith_numbers(5)

def test():
    for i, smith in enumerate(
            itertools.takewhile(
                lambda x: x < 1000000, smith_numbers()), 1):
        print i, smith

if __name__ == '__main__':
    test()
