#! coding: utf-8
u"""AquesTalk.dll, AquestTalkDA.dll を用いて音声合成する

作成
    fgshun (http://d.hatena.ne.jp/fgshun/)

関数
    talk
        サウンドデバイスより発声する
    synthe
        音声データを生成して返す
    write_wav
        音声データファイルを作成するショートカット関数
    AquesTalk_Synthe
        音声記号列から音声波形を生成する
    AquesTalk_FreeWave
        音声データの領域を開放
    AquesTalkDa_PlaySync
        同期タイプの音声合成
    AquesTalkDa_Create
        音声合成エンジンのインスタンスを生成（非同期タイプ）
    AquesTalkDa_Release
        音声合成エンジンのインスタンスを解放（非同期タイプ）
    AquesTalkDa_Play
        非同期タイプの音声合成
    AquesTalkDa_Stop
        発声の停止
    AquesTalkDa_IsPlay
        再生中か否か

例外
    AquesTalkError
        音声合成などの失敗を表す

AquesTalk_, AquesTalkDa_ で始まる関数は
AquesTalk.dll AquesTalkDa.dll の関数へのラッパーとなっている。
用いる際には AquesTalk Win 版に付属の『プログラミングガイド.pdf』、
および『音声記号列仕様』を参照のこと。
以下、これらの資料と挙動が異なる点について説明する。

AquesTalk_Synthe
    引数は (const char *koe, int iSpeed) の２つである。
    第３引数 int *pSize は無くなり、戻り値に含まれるようになっている。
    戻り値は 音声データへのポインタとその先のデータサイズのタプルである。
    音声データを Python 文字列型として得るには
        wav, size = AquesTalk_Synthe(koe='あいうえお', iSpeed=100)
        voice = wav[0:size]
        AquesTalk_FreeWave(wav)
    のようにする。

AquesTalkDa_PlaySync
AquesTalkDa_Play
    戻り値はなくなっている。異常終了した場合 AquesTalkError を送出する。
    ガイドに記されている本来の戻り値、エラーコード番号は
    この例外の err_code 属性に収まっている。

AquesTalkDa_IsPlay
    戻り値は整数ではなく bool 型。
    再生中ならば True, 再生中でなければ False 。
"""

from __future__ import with_statement
import os
import sys
from ctypes import windll, POINTER, WINFUNCTYPE
from ctypes import c_ulong, c_int, c_char, c_char_p, c_void_p
from ctypes.wintypes import HWND

__all__ = [
    'talk', 'synthe', 'write_wav', 'AquesTalkError',
    'AquesTalk_Synthe', 'AquesTalk_FreeWave',
    'AquesTalkDa_PlaySync', 'AquesTalkDa_Create', 'AquesTalkDa_Release',
    'AquesTalkDa_Play', 'AquesTalkDa_Stop', 'AquesTalkDa_IsPlay',]

version = '0.1.1'
version_info = (0, 1, 1)
dll_version = 'ver.2.1'
dll_version_info = (2, 1)

# 音声合成エンジンを示す型
H_AQTKDA = c_void_p

class AquesTalkError(Exception):
    u"""
    音声合成などの失敗を表す

    属性
        err_code 失敗理由をあらわす整数
    """
    err_messages = {
            100: u'その他のエラー',
            101: u'メモリ不足',
            102: u'音声記号列に未定義の読み記号が指定された',
            103: u'韻律データの時間長がマイナスなっている',
            104: u'内部エラー',
            105: u'音声記号列に未定義の読み記号が指定された',
            106: u'音声記号列のタグの指定が正しくない',
            107: u'タグの長さが制限を越えている',
            108: u'タグ内の値の指定が正しくない',
            109: u'WAVE 再生ができない',
            110: u'WAVE 再生ができない',
            111: u'発声すべきデータがない',
            200: u'音声記号列が長すぎる',
            201: u'１つのフレーズ中の読み記号が多すぎる',
            202: u'音声記号列が長い',
            203: u'ヒープメモリ不足',
            204: u'音声記号列が長い',
            }

    def __init__(self, err_code):
        self.err_code = err_code
        err_message = self.err_messages.get(self.err_code, '')
        if err_message:
            self.err_message = u'%d %s' % (
                    self.err_code, err_message)
        else:
            self.err_message = u'%d' % self.err_code

    def __unicode__(self):
        return self.err_message

    def __str__(self):
        return str(self.__unicode__())


def _errcheck(result, func, args):
    u"""戻り値として正常 0 異常 非0 を返す外部関数用の err_check 関数"""

    if result != 0:
        raise AquesTalkError(result)
    return None

def _synthecheck(result, func, args):
    u"""AquesTalk_Synthe 外部関数用の err_check 関数"""

    if not result:
        raise AquesTalkError(args[2].value)
    return result, args[2].value

def _isplaycheck(result, func, args):
    u"""AquesTalkDa_IsPlay 外部関数用の err_check 関数"""

    return bool(result)


# AquesTalk.dll wav 生成担当
try:
    _AquesTalk = windll.LoadLibrary(
            os.path.join(os.path.dirname(__file__), 'AquesTalk'))
except WindowsError:
    _AquesTalk = windll.AquesTalk

# 音声記号列から音声波形を生成する
_prototype = (POINTER(c_char), c_char_p, c_int, POINTER(c_int))
_paramflags = ((1, 'koe'), (1, 'iSpeed', 100), (2, 'pSize'))
AquesTalk_Synthe = WINFUNCTYPE(*_prototype)(
        ('AquesTalk_Synthe', _AquesTalk), _paramflags)
AquesTalk_Synthe.errcheck = _synthecheck

# 音声データの領域を開放
_prototype = (None, c_char_p)
_paramflags = ((1, 'wav'),)
AquesTalk_FreeWave = WINFUNCTYPE(*_prototype)(
        ('AquesTalk_FreeWave', _AquesTalk), _paramflags)

# AquesTalkDa.dll サウンドデバイス出力担当
try:
    _AquesTalkDa = windll.LoadLibrary(
            os.path.join(os.path.dirname(__file__), 'AquesTalkDa'))
except WindowsError:
    _AquesTalkDa = windll.AquesTalkDa

# 同期タイプの音声合成
_prototype = (c_int, c_char_p, c_int)
_paramflags = ((1, 'koe'), (1, 'iSpeed', 100))
AquesTalkDa_PlaySync = WINFUNCTYPE(*_prototype)(
        ('AquesTalkDa_PlaySync', _AquesTalkDa), _paramflags)
AquesTalkDa_PlaySync.errcheck = _errcheck

# 音声合成エンジンのインスタンスを生成（非同期タイプ）
_prototype = (H_AQTKDA,)
_paramflags = ()
AquesTalkDa_Create = WINFUNCTYPE(*_prototype)(
        ('AquesTalkDa_Create', _AquesTalkDa), _paramflags)

# 音声合成エンジンのインスタンスを解放（非同期タイプ）
_prototype = (None, H_AQTKDA)
_paramflags = ((1, 'hMe'),)
AquesTalkDa_Release = WINFUNCTYPE(*_prototype)(
        ('AquesTalkDa_Release', _AquesTalkDa), _paramflags)

# 非同期タイプの音声合成
_prototype = (c_int, H_AQTKDA, c_char_p, c_int, HWND, c_ulong, c_ulong)
_paramflags = (
        (1, 'hMe'), (1, 'koe'), (1, 'iSpeed', 100),
        (1, 'hWnd', 0), (1, 'msg', 0), (1, 'dwUser', 0))
AquesTalkDa_Play = WINFUNCTYPE(*_prototype)(
        ('AquesTalkDa_Play', _AquesTalkDa), _paramflags)
AquesTalkDa_Play.errcheck = _errcheck

# 発声の停止
_prototype = (None, H_AQTKDA)
_paramflags = ((1, 'hMe'),)
AquesTalkDa_Stop = WINFUNCTYPE(*_prototype)(
        ('AquesTalkDa_Stop', _AquesTalkDa), _paramflags)

# 再生中か否か
_prototype = (c_int, H_AQTKDA)
_paramflags = ((1, 'hMe'),)
AquesTalkDa_IsPlay = WINFUNCTYPE(*_prototype)(
        ('AquesTalkDa_IsPlay', _AquesTalkDa), _paramflags)
AquesTalkDa_IsPlay.errcheck = _isplaycheck

del _prototype
del _paramflags


def talk(sign, speed=100):
    u"""sign 音声記号列を元にサウンドデバイスより発声する
    
    同期タイプの処理のため発声終了するまで戻らない。

    引数:
        sign 音声記号列
        speed 発音速度 50 - 300
    戻り値:
        なし
    例外：
        AquesTalkError 発音失敗
    """

    if isinstance(sign, unicode):
        sign = sign.encode('cp932')
    AquesTalkDa_PlaySync(koe=sign, iSpeed=speed)

def synthe(sign, speed=100):
    u"""sign 音声記号列より音声データを生成して返す

    フォーマットは Microsoft Wave 。

    引数:
        sign 音声記号列
        speed 発音速度 50 - 300
    戻り値:
        音声データ
    例外：
        AquesTalkError 音声合成失敗
    """

    if isinstance(sign, unicode):
        sign = sign.encode('cp932')
    wav, size = AquesTalk_Synthe(koe=sign, iSpeed=speed)
    voice = wav[0:size]
    AquesTalk_FreeWave(wav=wav)
    return voice

def write_wav(path, sign, speed=100):
    u"""音声データファイルを作成するショートカット関数

    フォーマットは Microsoft Wave 。

    引数:
        path Wave データを保存するファイルパス
        sign 音声記号列
        speed 発音速度 50 - 300
    戻り値:
        なし
    例外：
        AquesTalkError 音声合成失敗
    """

    voice = synthe(sign, speed)
    with open(path, 'wb') as f:
        f.write(voice)

def main():
    if len(sys.argv) < 2:
        exe = os.path.basename(__file__)
        sys.stderr.write(u'usage: %s voice_sign\n' % exe)
        sys.stderr.write(u'ex: %s あくえすとーく\n' % exe)
        sys.exit(1)

    for sign in sys.argv[1:]:
        talk(sign)

if __name__ == '__main__':
    main()
