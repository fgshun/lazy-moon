# coding: utf-8
u"""py2exe 用ユーティリティ関数
"""

import os
import sys
import imp
import locale
import __main__

class Py2exeHelperError(Exception):
    pass

def setdefaultencoding(coding=None):
    if hasattr(sys, 'setdefaultencoding'):
        if not coding:
            coding = 'ascii'
            loc = locale.getdefaultlocale()
            if loc[1]:
                coding = loc[1]
        sys.setdefaultencoding(coding)
        return True
    return False

def is_frozen():
    u"""
    自身が py2exe などで固められているかどうかを判別する
    """
    return (hasattr(sys, 'frozen') or    # new py2exe
            hasattr(sys, 'importers') or # old py2exe
            imp.is_frozen('__main__')    # tools/freeze
            )

def get_main_file():
    u"""
    実行ファイルのパスを返す。
    """
    if is_frozen():
        mainfile = unicode(sys.executable)
    elif hasattr(__main__, '__file__'):
        mainfile = unicode(__main__.__file__)
    else:
        raise Py2exeHelperError(
                u'the exe is not found.')
    # 確認した範囲内では 絶対パスが返っているようだが、
    # 念のため os.path.abspath で処理する。
    return os.path.abspath(mainfile)

def get_main_dir():
    u"""
    実行ファイルの存在するディレクトリを返す。
    """
    try:
        mainfile = get_main_file()
    except Py2exeHelperError:
        raise Py2exeHelperError(
                u'the directory of the exe is not found.')
    return os.path.abspath(os.path.dirname(mainfile))

# a old function name
get_maindir = get_main_dir
