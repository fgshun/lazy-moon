# coding: utf-8
u"""プログラミング言語てってってー
"""

import sys
import os
import re
import codecs
import array
import optparse
from shun.py2exehelper import setdefaultencoding

setdefaultencoding()

ENCODING = sys.getdefaultencoding()
#ENCODING = 'utf_8'
#ENCODING = 'euc_jp'
#ENCODING = 'shift_jis'

MAX_B = 65535 # B に保持する値を 0-65535 にしている
MAX_P = 65535 # P ポインタ最大値(B 配列長)のデフォルト値の指定

class TettetteeError(Exception):
    pass

class ParseError(TettetteeError):
    pass

class RunError(TettetteeError):
    pass

class Statement(object):
    def __init__(self, statement, data, code_position):
        self.statement = statement
        self.data = data
        self.code_position = code_position

    def __unicode__(self):
        return u'%s, %s, %d' % (self.statement, self.data, self.code_position)

    def __str__(self):
        return str(self.__unicode__())

    def __repr__(self):
        return '%s(statement=%r, data=%r, code_position=%r)' % (
                self.__class__.__name__,
                self.statement, self.data, self.code_position)

class Tettettee(object):
    def __init__(
            self,
            code,
            reader=codecs.getreader(ENCODING)(sys.stdin),
            writer=codecs.getwriter(ENCODING)(sys.stdout),
            max_p=MAX_P):
        self.code = code
        self.statements = list(self.parse(code))
        self.statements_length = len(self.statements)
        self.B = array.array('H', (0 for _ in xrange(max_p+1)))
        self.P = 0
        self.SN = 0
        self.S = []
        self.reader = reader
        self.writer = writer
        self.max_p = max_p

    _re_parse = re.compile(
            u'''
            (?P<prolonged_sound>ー.*?てー) |
            ててー |
            てっー |
            てってー |
            てっててー |
            てってっー |
            てってってー |
            てってっててー |
            てってってっー |
            (?P<whitespace>[\x20\u3000\x09\x0a\x0d]+) |
            (?P<comment>{.*?}) |
            (?P<invalid>.)
            ''',
            re.VERBOSE|re.DOTALL)
    @classmethod
    def parse(cls, code):
        for mo in cls._re_parse.finditer(code):
            statement = mo.group(0)
            start = mo.start()
            if mo.group('invalid') is not None:
                raise ParseError(u'Parse Error: %d' % start)
            elif mo.group('prolonged_sound'):
                yield Statement(statement[0], statement[1:-2], start)
            elif mo.group('comment'):
                yield Statement(u'Comment', statement[1:-1], start)
            elif mo.group('whitespace'):
                yield Statement(u'Whitespace', statement, start)
            else:
                yield Statement(statement, None, start)

    def prolonged_sound(self, statement):
        for c in statement.data:
            self.B[self.P] = ord(c)
            self.P += 1

    def tetee(self, statement):
        if self.B[self.P] < MAX_B:
            self.B[self.P] += 1
        else:
            self.B[self.P] -= MAX_B

    def textuu(self, statement):
        if self.B[self.P] > 0:
            self.B[self.P] -= 1
        else:
            self.B[self.P] += MAX_B

    def tettee(self, statement):
        if self.P >= self.max_p:
            raise TettetteeError(
                    u'P ポインタ変数は %d 以上にできません' % (
                        self.max_p))
        self.P += 1

    def tettetee(self, statement):
        if self.P <= 0:
            raise TettetteeError(u'P ポインタ変数は 0 以下にできません')
        self.P -= 1

    def tettextuu(self, statement):
        self.writer.write(unichr(self.B[self.P]).encode())
        self.P += 1

    def tettettee(self, statement):
        c = self.reader.read(1)
        if c:
            self.B[self.P] = ord(c)
            self.P += 1
        else:
            raise TettetteeError(u'「てってってー」入力エラー')

    def tettettetee(self, statement):
        if self.B[self.P]:
            self.S.append(self.SN - 1)
        else:
            while self.SN < self.statements_length:
                statement = self.statements[self.SN]
                self.SN += 1
                if statement.statement == u'てってってっー':
                    break
            else:
                raise RunError(
                        u'「てってってー」中にファイル終端に到達しました')

    def tettettextuu(self, statement):
        try:
            self.SN = self.S.pop()
        except IndexError, e:
            raise RunError(u'「てってってっー」S が空です'), \
                    None, sys.exc_info()[2]

    action = {
            u'ー': prolonged_sound,
            u'ててー': tetee,
            u'てっー': textuu,
            u'てってー': tettee,
            u'てっててー': tettetee,
            u'てってっー': tettextuu,
            u'てってってー': tettettee,
            u'てってっててー': tettettetee,
            u'てってってっー': tettettextuu,
            }

    def run(self):
        while self.SN < self.statements_length:
            statement = self.statements[self.SN]
            self.SN += 1
            if statement.statement in self.action:
                self.action[statement.statement](self, statement)

class Args(object):
    def __str__(self):
        return str(self.__dict__)

    def __repr__(self):
        return "<%s at 0x%x: %s>" % (
                self.__class__.__name__, id(self), self)

def parse_args():
    u"""
    """
    usage = u'Usage: %prog code'
    version = u'%prog 0.1.0'
    parser = optparse.OptionParser(usage=usage, version=version)
    options, args_list = parser.parse_args()

    if len(args_list) != 1:
        parser.error(u'入力ファイルを指定してください')

    args = Args()
    args.code, = args_list

    if not os.path.isfile(args.code):
        parser.error(u'入力ファイルがありません')

    return options, args, parser

def main():
    options, args, parser = parse_args()

    code = codecs.open(args.code, 'r', ENCODING).read()
    parser = Tettettee(code)
    parser.run()

if __name__ == '__main__':
    main()
