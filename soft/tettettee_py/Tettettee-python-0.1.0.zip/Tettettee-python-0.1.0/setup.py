# encoding: utf-8

from distutils.core import setup
import py2exe

py2exe_options = {'compressed': 1,
                  'optimize': 2,
                  'bundle_files': 1,
                  }

setup(
        name='Tettettee-python',
        version='0.1.0',
        description='Programing Language Tettettee on Python',
        author='fgshun',
        author_email='fgshun@lazy-moon.jp',
        url='http://d.hatena.ne.jp/fgshun/',
        packages=['shun'],
        py_modules=['tettettee'],
        options={'py2exe': py2exe_options},
        console=[{'script' : 'tettettee.py'}],
        zipfile=None,
      ) 
