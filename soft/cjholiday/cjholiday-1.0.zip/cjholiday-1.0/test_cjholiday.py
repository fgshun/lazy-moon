import unittest
import datetime

import jholiday
import cjholiday

class HolidayNameTestCase(unittest.TestCase):
    def test_holiday_name(self):
        start = datetime.date(1950, 1, 1)
        end = datetime.date(2150, 1, 1)
        #start = datetime.date(1, 1, 1)
        #end = datetime.date(9999, 12, 30)

        j = jholiday.holiday_name
        c = cjholiday.holiday_name

        date = start
        d1 = datetime.timedelta(days=1)
        while date < end:
            self.assertEqual(
                    j(date.year, date.month, date.day),
                    c(date.year, date.month, date.day))
            date += d1

    def test_holiday_name_date(self):
        start = datetime.date(1950, 1, 1)
        end = datetime.date(2150, 1, 1)
        #start = datetime.date(1, 1, 1)
        #end = datetime.date(9999, 12, 30)

        j = jholiday.holiday_name
        c = cjholiday.holiday_name_date

        date = start
        d1 = datetime.timedelta(days=1)
        while date < end:
            self.assertEqual(
                    j(date.year, date.month, date.day),
                    c(date))
            date += d1

if __name__ == '__main__':
    unittest.main()
