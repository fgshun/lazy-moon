#include <Python.h>
#include <datetime.h>

/*
//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
//_/
//_/  CopyRight(C) K.Tsunoda(AddinBox) 2001 All Rights Reserved.
//_/  ( http://www.h3.dion.ne.jp/~sakatsu/index.htm )
//_/
//_/    ���̏j������R�[�h�́wExcel:kt�֐��A�h�C���x�Ŏg�p���Ă�����̂ł��B
//_/    ���̊֐��ł́A�Q�O�P�U�N�{�s�̉����j���@(�R�̓�)�܂ł�
//_/  �@�T�|�[�g���Ă��܂��B
//_/
//_/  (*1)���̃R�[�h�����p����ɓ������ẮA�K�����̃R�����g��
//_/      �ꏏ�Ɉ��p���鎖�Ƃ��܂��B
//_/  (*2)���T�C�g��Ŗ{�}�N���𒼐ڈ��p���鎖�́A�������肢�܂��B
//_/      �y http://www.h3.dion.ne.jp/~sakatsu/holiday_logic.htm �z
//_/      �ւ̃����N�ɂ��Љ�őΉ����ĉ������B
//_/  (*3)[ktHolidayName]�Ƃ����֐������̂��̂́A�e���̊���
//_/      �����閽���K���ɉ����ĕύX���Ă��\���܂���B
//_/  
//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
*/

/*
 * fgshun  http://d.hatena.ne.jp/fgshun/
 *
 * 2009/11/18
 * ���̃R�[�h��
 * SETOGUCHI Mitsuhiro (http://matatabi.homeip.net/) ���̃X�N���v�g
 * (http://www.h3.dion.ne.jp/~sakatsu/holiday_logic5.htm#Python)
 * �� fgshun �� C �G�N�X�e���V�����Ƃ��đg�݂Ȃ��������̂ł��B
 *
 * 2014/9/14
 * �I���W�i�� 2010/9/21 holiday_name �֐��L�[���[�h�����̒ǉ��𔽉f�B
 * �I���W�i�� 2014/5/29 �R�̓��̏C���𔽉f�B
 */

static PyObject *DATE_CLASS;
static PyObject *DELTA_DAY1;

/* ���� */
static PyObject *H_GANJITSU;
static Py_UCS4 U_GANJITSU[] = {
    0x5143, 0x65e5};
/* ���l�̓� */
static PyObject *H_SEIJINNOHI;
static Py_UCS4 U_SEIJINNOHI[] = {
    0x6210, 0x4eba, 0x306e, 0x65e5};
/* �����L�O�̓� */
static PyObject *H_KENKOKUKINENNOHI;
static Py_UCS4 U_KENKOKUKINENNOHI[] = {
    0x5efa, 0x56fd, 0x8a18, 0x5ff5, 0x306e, 0x65e5};
/* �t���̓� */
static PyObject *H_SHUNBUNNOHI;
static Py_UCS4 U_SHUNBUNNOHI[] = {
    0x6625, 0x5206, 0x306e, 0x65e5};
/* ���a�̓� */
static PyObject *H_SHOWANOHI;
static Py_UCS4 U_SHOWANOHI[] = {
    0x662d, 0x548c, 0x306e, 0x65e5};
/* ���@�L�O�� */
static PyObject *H_KENPOKINENBI;
static Py_UCS4 U_KENPOKINENBI[] = {
    0x61b2, 0x6cd5, 0x8a18, 0x5ff5, 0x65e5};
/* �݂ǂ�̓� */
static PyObject *H_MIDORINOHI;
static Py_UCS4 U_MIDORINOHI[] = {
    0x307f, 0x3069, 0x308a, 0x306e, 0x65e5};
/* ���ǂ��̓� */
static PyObject *H_KODOMONOHI;
static Py_UCS4 U_KODOMONOHI[] = {
    0x3053, 0x3069, 0x3082, 0x306e, 0x65e5};
/* �C�̓� */
static PyObject *H_UMINOHI;
static Py_UCS4 U_UMINOHI[] = {
    0x6d77, 0x306e, 0x65e5};
/* �R�̓� */
static PyObject *H_YAMANOHI;
static Py_UCS4 U_YAMANOHI[] = {
    0x5c71, 0x306e, 0x65e5};
/* �h�V�̓� */
static PyObject *H_KEIRONOHI;
static Py_UCS4 U_KEIRONOHI[] = {
    0x656c, 0x8001, 0x306e, 0x65e5};
/* �H���̓� */
static PyObject *H_SHUBUNNOHI;
static Py_UCS4 U_SHUBUNNOHI[] = {
    0x79cb, 0x5206, 0x306e, 0x65e5};
/* �̈�̓� */
static PyObject *H_TAIKUNOHI;
static Py_UCS4 U_TAIKUNOHI[] = {
    0x4f53, 0x80b2, 0x306e, 0x65e5};
/* �����̓� */
static PyObject *H_BUNKANOHI;
static Py_UCS4 U_BUNKANOHI[] = {
    0x6587, 0x5316, 0x306e, 0x65e5};
/* �ΘJ���ӂ̓� */
static PyObject *H_KINROKANSHANOHI;
static Py_UCS4 U_KINROKANSHANOHI[] = {
    0x52e4, 0x52b4, 0x611f, 0x8b1d, 0x306e, 0x65e5};
/* �V�c�a���� */
static PyObject *H_TENNOTANJOBI;
static Py_UCS4 U_TENNOTANJOBI[] = {
    0x5929, 0x7687, 0x8a95, 0x751f, 0x65e5};

/* �U�֋x�� */
static PyObject *H_FURIKAEKYUJITSU;
static Py_UCS4 U_FURIKAEKYUJITSU[] = {
    0x632f, 0x66ff, 0x4f11, 0x65e5};
/* �����̋x�� */
static PyObject *H_KOKUMINNOKYUJITSU;
static Py_UCS4 U_KOKUMINNOKYUJITSU[] = {
    0x56fd, 0x6c11, 0x306e, 0x4f11, 0x65e5};

/* �c���q���m�e���̌����̋V */
static PyObject *H_KOUTAISHIAKIHITOSHINNOUNOKEKKONNOGI;
static Py_UCS4 U_KOUTAISHIAKIHITOSHINNOUNOKEKKONNOGI[] = {
    0x7687, 0x592a, 0x5b50, 0x660e, 0x4ec1, 0x89aa, 0x738b, 0x306e,
    0x7d50, 0x5a5a, 0x306e, 0x5100};
/* ���a�V�c�̑�r�̗� */
static PyObject *H_SHOWATENNOUNOTAIMOUNOREI;
static Py_UCS4 U_SHOWATENNOUNOTAIMOUNOREI[] = {
    0x662d, 0x548c, 0x5929, 0x7687, 0x306e, 0x5927, 0x55aa, 0x306e,
    0x793c};
/* ���ʗ琳�a�̋V */
static PyObject *H_SOKUIREISEIDENNOGI;
static Py_UCS4 U_SOKUIREISEIDENNOGI[] = {
    0x5373, 0x4f4d, 0x793c, 0x6b63, 0x6bbf, 0x306e, 0x5100};
/* �c���q���m�e���̌����̋V */
static PyObject *H_KOUTAISHINARUHITOSHINNOUNOKEKKONNOGI;
static Py_UCS4 U_KOUTAISHINARUHITOSHINNOUNOKEKKONNOGI[] = {
    0x7687, 0x592a, 0x5b50, 0x5fb3, 0x4ec1, 0x89aa, 0x738b, 0x306e,
    0x7d50, 0x5a5a, 0x306e, 0x5100};

static long vernal_equinox(long year) {
    long day;
    if (year <= 1947){
        day = 0;
    } else if (year <= 1979){
        day = (long)(20.8357 + (0.242194 * (year - 1980)) -
                (year - 1983) / 4);
    } else if (year <= 2099){
        day = (long)(20.8431 + (0.242194 * (year - 1980)) -
                (year - 1980) / 4);
    } else if (year <= 2150){
        day = (long)(21.851 + (0.242194 * (year - 1980)) -
                (year - 1980) / 4);
    } else {
        day = 0;
    }

    return day;
}

static long autumn_equinox(long year) {
    long day;
    if (year <= 1947){
        day = 0;
    } else if (year <= 1979){
        day = (long)(23.2588 + (0.242194 * (year - 1980)) -
                (year - 1983) / 4);
    } else if (year <= 2099){
        day = (long)(23.2488 + (0.242194 * (year - 1980)) -
                (year - 1980) / 4);
    } else if (year <= 2150){
        day = (long)(24.2488 + (0.242194 * (year - 1980)) -
                (year - 1980) / 4);
    } else {
        day = 0;
    }

    return day;
}

static PyObject *
holiday_name_date2(PyObject *date) {
    long year, month, day;
    long autumn;
    long weekday = -1;
    PyObject *name = Py_None;

    year = PyDateTime_GET_YEAR(date);
    month = PyDateTime_GET_MONTH(date);
    day = PyDateTime_GET_DAY(date);

    if (year < 1948) {
        Py_RETURN_NONE;
    }
    else if (year == 1948) {
        if (month < 7) {
            Py_RETURN_NONE;
        }
        else if (month == 7 && day < 20) {
            Py_RETURN_NONE;
        }
    }

    switch (month) {
        case 1:
            if (day == 1) {
                name = H_GANJITSU;
            }
            else if (year >= 2000) {
                if ((day - 1) / 7 == 1) {
                    PyObject *weekday_py;
                    weekday_py = PyObject_CallMethod(date, "weekday", NULL);
                    if (weekday_py == NULL) return NULL;
                    weekday = PyLong_AS_LONG(weekday_py);
                    Py_DECREF(weekday_py);
                    if (weekday == 0) {
                        name = H_SEIJINNOHI;
                    }
                }
            }
            else if (day == 15) {
                name = H_SEIJINNOHI;
            }
            break;
        case 2:
            if (day == 11 && year >= 1967) {
                name = H_KENKOKUKINENNOHI;
            }
            else if (year == 1989 && day == 24) {
                /* 1989/2/24 */
                name = H_SHOWATENNOUNOTAIMOUNOREI;
            }
            break;
        case 3:
            if (day == vernal_equinox(year)) {
                name = H_SHUNBUNNOHI;
            }
            break;
        case 4:
            if (day == 29) {
                if (year >= 2007) {
                    name = H_SHOWANOHI;
                }
                else if (year >= 1989) {
                    name = H_MIDORINOHI;
                }
                else {
                    name = H_TENNOTANJOBI;
                }
            }
            else if (year == 1959 && day == 10) {
                /* 1959/4/10 */
                name = H_KOUTAISHIAKIHITOSHINNOUNOKEKKONNOGI;
            }
            break;
        case 5:
            if (day == 3) {
                name = H_KENPOKINENBI;
            }
            else if (day == 4) {
                if (year >= 2007) {
                    name = H_MIDORINOHI;
                }
                else if (year >= 1986) {
                    PyObject *weekday_py;
                    weekday_py = PyObject_CallMethod(date, "weekday", NULL);
                    if (weekday_py == NULL) return NULL;
                    weekday = PyLong_AS_LONG(weekday_py);
                    Py_DECREF(weekday_py);
                    if (weekday != 0) {
                        name = H_KOKUMINNOKYUJITSU;
                    }
                }
            }
            else if (day == 5) {
                name = H_KODOMONOHI;
            }
            else if (day == 6) {
                if (year >= 2007) {
                    PyObject *weekday_py;
                    weekday_py = PyObject_CallMethod(date, "weekday", NULL);
                    if (weekday_py == NULL) return NULL;
                    weekday = PyLong_AS_LONG(weekday_py);
                    Py_DECREF(weekday_py);
                    if (weekday == 1 || weekday == 2) {
                        name = H_FURIKAEKYUJITSU;
                    }
                }
            }
            break;
        case 6:
            if (year == 1993 && day == 9) {
                /* 1993/6/9 */
                name = H_KOUTAISHINARUHITOSHINNOUNOKEKKONNOGI;
            }
            break;
        case 7:
            if (year >= 2003) {
                if ((day - 1) / 7 == 2) {
                    PyObject *weekday_py;
                    weekday_py = PyObject_CallMethod(date, "weekday", NULL);
                    if (weekday_py == NULL) return NULL;
                    weekday = PyLong_AS_LONG(weekday_py);
                    Py_DECREF(weekday_py);
                    if (weekday == 0) {
                        name = H_UMINOHI;
                    }
                }
            }
            else if (year >= 1996 && day == 20) {
                name = H_UMINOHI;
            }
            break;
        case 8:
            if (year >= 2016 && day == 11) {
                name = H_YAMANOHI;
            }
            break;
        case 9:
            autumn = autumn_equinox(year);
            if (day == autumn) {
                name = H_SHUBUNNOHI;
            }
            else {
                if (year >= 2003) {
                    PyObject *weekday_py;
                    weekday_py = PyObject_CallMethod(
                            date, "weekday", NULL);
                    if (weekday_py == NULL) return NULL;
                    weekday = PyLong_AS_LONG(weekday_py);
                    Py_DECREF(weekday_py);
                    if ((day - 1) / 7 == 2 && weekday == 0) {
                        name = H_KEIRONOHI;
                    }
                    else if (weekday == 1 && day == autumn - 1) {
                        name = H_KOKUMINNOKYUJITSU;
                    }
                }
                else if (year >= 1966 && day == 15) {
                    name = H_KEIRONOHI;
                }
            }
            break;
        case 10:
            if (year >= 2000) {
                if ((day - 1) / 7 == 1) {
                    PyObject *weekday_py;
                    weekday_py = PyObject_CallMethod(date, "weekday", NULL);
                    if (weekday_py == NULL) return NULL;
                    weekday = PyLong_AS_LONG(weekday_py);
                    Py_DECREF(weekday_py);
                    if (weekday == 0) {
                        name = H_TAIKUNOHI;
                    }
                }
            }
            else if (year >= 1966 && day == 10) {
                name = H_TAIKUNOHI;
            }
            break;
        case 11:
            if (day == 3) {
                name = H_BUNKANOHI;
            }
            else if (day == 23) {
                name = H_KINROKANSHANOHI;
            }
            else if (year == 1990 && day == 12) {
                name = H_SOKUIREISEIDENNOGI;
            }
            break;
        case 12:
            if (day == 23 && year >= 1989) {
                name = H_TENNOTANJOBI;
            }
    }

    if (name == Py_None) {
        if (weekday < 0) {
            PyObject *weekday_py;
            weekday_py = PyObject_CallMethod(date, "weekday", NULL);
            if (weekday_py == NULL) return NULL;
            weekday = PyLong_AS_LONG(weekday_py);
            Py_DECREF(weekday_py);
        }
        if (weekday == 0) {
            PyObject *prev, *prev_name;
            int prev_bool;
            prev = PyNumber_Subtract(date, DELTA_DAY1);
            if (prev == NULL) {
                return NULL;
            }
            prev_name = holiday_name_date2(prev);
            if (prev_name == NULL) {
                Py_DECREF(prev);
                return NULL;
            }
            prev_bool = PyObject_IsTrue(prev_name);
            if (prev_bool == 1) {
                name = H_FURIKAEKYUJITSU;
            }
            else if (prev_bool == -1) {
                Py_DECREF(prev);
                Py_DECREF(prev_name);
                return NULL;
            }
            Py_DECREF(prev);
            Py_DECREF(prev_name);
        }
    }

    Py_INCREF(name);
    return name;
}

static PyObject *
holiday_name_date(PyObject *self, PyObject *args, PyObject *kwargs) {
    PyObject *date, *result = NULL;
    static char *kwlist[] = {"date", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O", kwlist, &date)) {
        return NULL;
    }

    if (PyDate_Check(date)) {
        result = holiday_name_date2(date);
    }

    return result;
}

static PyObject *
holiday_name(PyObject *self, PyObject *args, PyObject *kwargs) {
    PyObject *result;
    PyObject *year = NULL, *month = NULL, *day = NULL, *date = NULL;
    PyObject *temp;
    PyObject *s;
    static char *kwlist[] = {"year", "month", "day", "date", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "|OOOO", kwlist, &year, &month, &day, &date)) {
        return NULL;
    }

    if (date != NULL && PyDate_Check(date)) {
        result = holiday_name_date2(date);
        return result;
    } else if (PyNumber_Check(year) && PyNumber_Check(month) && PyNumber_Check(day)) {
        temp = Py_BuildValue("(OOO)", year, month, day);
        date = PyObject_Call(DATE_CLASS, temp, NULL);
        if (date == NULL) {
            return NULL;
        }
        result = holiday_name_date2(date);
        Py_DECREF(date);
        Py_DECREF(temp);
        return result;
    } else {
        s = PyUnicode_FromString(
                "year, month, day is not int or date is not datetime.date");
        PyErr_SetObject(PyExc_TypeError, s);
        Py_DECREF(s);
        return NULL;
    }
}

static PyMethodDef cjholiday_method[] = {
    {"holiday_name_date", (PyCFunction)holiday_name_date,
     METH_VARARGS | METH_KEYWORDS,
     "get name of holiday from datetime.date."},
    {"holiday_name", (PyCFunction)holiday_name,
     METH_VARARGS | METH_KEYWORDS,
     "get name of holiday from ymd."},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef cjholiday_module = {
    PyModuleDef_HEAD_INIT,
    "cjholiday",   /* name of module */
    NULL, /* module documentation, may be NULL */ // TODO: Holiday of Japan
    -1,       /* size of per-interpreter state of the module,
                 or -1 if the module keeps state in global variables. */
    cjholiday_method
};

PyMODINIT_FUNC PyInit_cjholiday(void) {
    PyObject *module;
    PyObject *datetime_module;

    module = PyModule_Create(&cjholiday_module);
    if (module == NULL) return NULL;

    /* version */
    if (PyModule_AddStringConstant(module, "version", "1.0.3"))
        return NULL;

    /* ���� */
    if ((H_GANJITSU = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_GANJITSU, 2)) == NULL)
        return NULL;
    /* ���l�̓� */
    if ((H_SEIJINNOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_SEIJINNOHI, 4)) == NULL)
        return NULL;
    /* �����L�O�̓� */
    if ((H_KENKOKUKINENNOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_KENKOKUKINENNOHI, 6))
            == NULL)
        return NULL;
    /* �t���̓� */
    if ((H_SHUNBUNNOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_SHUNBUNNOHI, 4))
            == NULL)
        return NULL;
    /* ���a�̓� */
    if ((H_SHOWANOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_SHOWANOHI, 4))
            == NULL)
        return NULL;
    /* ���@�L�O�� */
    if ((H_KENPOKINENBI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_KENPOKINENBI, 5))
            == NULL)
        return NULL;
    /* �݂ǂ�̓� */
    if ((H_MIDORINOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_MIDORINOHI, 5))
            == NULL)
        return NULL;
    /* ���ǂ��̓� */
    if ((H_KODOMONOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_KODOMONOHI, 5))
            == NULL)
        return NULL;
    /* �C�̓� */
    if ((H_UMINOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_UMINOHI, 3))
            == NULL)
        return NULL;
    /* �R�̓� */
    if ((H_YAMANOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_YAMANOHI, 3))
            == NULL)
        return NULL;
    /* �h�V�̓� */
    if ((H_KEIRONOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_KEIRONOHI, 4))
            == NULL)
        return NULL;
    /* �H���̓� */
    if ((H_SHUBUNNOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_SHUBUNNOHI, 4))
            == NULL)
        return NULL;
    /* �̈�̓� */
    if ((H_TAIKUNOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_TAIKUNOHI, 4))
            == NULL)
        return NULL;
    /* �����̓� */
    if ((H_BUNKANOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_BUNKANOHI, 4))
            == NULL)
        return NULL;
    /* �ΘJ���ӂ̓� */
    if ((H_KINROKANSHANOHI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_KINROKANSHANOHI, 6))
            == NULL)
        return NULL;
    /* �V�c�a���� */
    if ((H_TENNOTANJOBI = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_TENNOTANJOBI, 5))
            == NULL)
        return NULL;

    /* �U�֋x�� */
    if ((H_FURIKAEKYUJITSU = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_FURIKAEKYUJITSU, 4))
            == NULL)
        return NULL;
    /* �����̋x�� */
    if ((H_KOKUMINNOKYUJITSU =
                PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_KOKUMINNOKYUJITSU, 5))
            == NULL)
        return NULL;

    /* �c���q���m�e���̌����̋V */
    if ((H_KOUTAISHIAKIHITOSHINNOUNOKEKKONNOGI =
        PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_KOUTAISHIAKIHITOSHINNOUNOKEKKONNOGI, 12))
            == NULL)
        return NULL;
    /* ���a�V�c�̑�r�̗� */
    if ((H_SHOWATENNOUNOTAIMOUNOREI = 
                PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_SHOWATENNOUNOTAIMOUNOREI, 9))
            == NULL)
        return NULL;
    /* ���ʗ琳�a�̋V */
    if ((H_SOKUIREISEIDENNOGI =
                PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_SOKUIREISEIDENNOGI, 7))
            == NULL)
        return NULL;
    /* �c���q���m�e���̌����̋V */
    if ((H_KOUTAISHINARUHITOSHINNOUNOKEKKONNOGI =
        PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, U_KOUTAISHINARUHITOSHINNOUNOKEKKONNOGI, 12))
            == NULL)
        return NULL;

    /* datetime.date �I�u�W�F�N�g�𓾂� */
    datetime_module = PyImport_ImportModule("datetime");
    if (datetime_module == NULL) {
        return NULL;
    }
    DATE_CLASS = PyObject_GetAttrString(datetime_module, "date");
    if (DATE_CLASS == NULL) {
        return NULL;
    }
    Py_DECREF(datetime_module);

    /* datetime �֘A�� C API ���g����悤�ɂ��� */
    PyDateTime_IMPORT;

    /* datetime.timedelta(days=1) */
    if ((DELTA_DAY1 = PyDelta_FromDSU(1, 0, 0)) == NULL) {
        return NULL;
    }

    return module;
}

/*
//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
//_/ CopyRight(C) K.Tsunoda(AddinBox) 2001 All Rights Reserved.
//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
*/
