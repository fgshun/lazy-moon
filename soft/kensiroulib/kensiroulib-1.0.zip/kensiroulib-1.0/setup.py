from distutils.core import setup, Extension

py_modules = ['test_kensiroulib']
packages = ['kensiroulib']

_ver1 = Extension('kensiroulib._ver1', ['kensiroulib/_ver1.c'])
_ver2 = Extension('kensiroulib._ver2', ['kensiroulib/_ver2.c'])
_runlength = Extension('kensiroulib._runlength', ['kensiroulib/_runlength.c'])

ext_modules = [_ver1, _ver2, _runlength]

setup (name='kensiroulib',
       version='1.0',
       description='Atatatatata.',
       py_modules=py_modules,
       packages=packages,
       ext_modules=ext_modules)
