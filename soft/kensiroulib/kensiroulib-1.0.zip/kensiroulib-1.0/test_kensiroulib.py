# coding: utf-8

import unittest
import sys
import os
import itertools

from kensiroulib import ver1
from kensiroulib import ver2
from kensiroulib import runlength

if sys.version_info < (3,):
    def bytes(iterable):
        return b''.join(chr(c) for c in iterable)

class TestVer1(unittest.TestCase):
    intdata = {
        0b0: u'た',
        0b1: u'あ',
        0b10: u'あた',
        0b11: u'ああ',
        0b100: u'あたた',
        0b101: u'あたあ',
        0b110: u'ああた',
        0b111: u'あああ',
        0b1000: u'あたたた',
        0b1001: u'あたたあ',
        0b1010: u'あたあた',
        0b1011: u'あたああ',
        0b1100: u'ああたた',
        0b1101: u'ああたあ',
        0b1110: u'あああた',
        0b1111: u'ああああ',
        0xff: u'ああああああああ', # 世紀末覇王数 255
        0x100: u'あたたたたたたたた',
        0xffff: u'あ' * (4*4),
        0x10000: u'あ' + u'た' * (4*4),
        0xffffffff: u'あ' * (4*8),
        0x100000000: u'あ' + u'た' * (4*8),
        0xffffffffffffffff: u'あ' * (4*16),
        0x10000000000000000: u'あ' + u'た' * (4*16),
        0xffffffffffffffffffffffffffffffff: u'あ' * (4*32),
        0x100000000000000000000000000000000: u'あ' + u'た' * (4*32),
        }

    def testencodeint(self):
        for i, s in self.intdata.iteritems():
            self.assertEqual(ver1.encode_int(i), s)

    def testdecodeint(self):
        for i, s in self.intdata.iteritems():
            self.assertEqual(ver1.decode_int(s), i)

    def testencodedecode(self):
        with open(__file__, 'rb') as f:
            data = f.read()
        s = ver1.encode(data)
        b = ver1.decode(s)

        self.assertEqual(len(data) * 8, len(s))
        self.assertEqual(data, b)

class TestVer2(unittest.TestCase):
    intdata = {
        0b0: u'',
        0b1: u'あた',
        0b10: u'あた た',
        0b11: u'あたた',
        0b100: u'あた たた',
        0b101: u'あた たあた',
        0b110: u'あたた た',
        0b111: u'あたたた',
        0b1000: u'あた たたた',
        0b1001: u'あた たたあた',
        0b1010: u'あた たあた た',
        0b1011: u'あた たあたた',
        0b1100: u'あたた たた',
        0b1101: u'あたた たあた',
        0b1110: u'あたたた た',
        0b1111: u'あたたたた',
        0xff: u'あたたたたたたたた', # 世紀末覇王数 255
        0x100: u'あた たたたたたたたた',
        0xffff: u'あ' + u'た' * (4*4),
        0x10000: u'あた ' + u'た' * (4*4),
        0xffffffff: u'あ' + u'た' * (4*8),
        0x100000000: u'あた ' + u'た' * (4*8),
        0xffffffffffffffff: u'あ' + u'た' * (4*16),
        0x10000000000000000: u'あた ' + u'た' * (4*16),
        0xffffffffffffffffffffffffffffffff: u'あ' + u'た' * (4*32),
        0x100000000000000000000000000000000: u'あた ' + u'た' * (4*32),
        }

    def testencodeint(self):
        for i, s in self.intdata.iteritems():
            self.assertEqual(ver2.encode_int(i), s)

    def testdecodeint(self):
        for i, s in self.intdata.iteritems():
            self.assertEqual(ver2.decode_int(s), i)

    def testencodedecode(self):
        with open(__file__, 'rb') as f:
            data = f.read()
        s = ver2.encode(data)
        b = ver2.decode(s)

        self.assertEqual(
                len(data) * 8,
                s.count(u'た'))
        self.assertEqual(data, b)

class TestRunlength(unittest.TestCase):
    intdata = {
        0b0: u'た',
        0b1: u'あ',
        0b10: u'あた',
        0b11: u'あー',
        0b100: u'あたー',
        0b101: u'あたあ',
        0b110: u'あーた',
        0b111: u'あっ',
        0b1000: u'あたっ',
        0b1001: u'あたーあ',
        0b1010: u'あたあた',
        0b1011: u'あたあー',
        0b1100: u'あーたー',
        0b1101: u'あーたあ',
        0b1110: u'あった',
        0b1111: u'あぁ',
        0xff: u'あぉぁ', # 世紀末覇王数 255
        0x100: u'あたぉぁ',
        0xffff: u'あぉぉぉぁ',
        0x10000: u'あたぉぉぉぁ',
        0xffffffff: u'あ' + u'ぉ' * (8-1) + u'ぁ',
        0x100000000: u'あた' + u'ぉ' * (8-1) + u'ぁ',
        0xffffffffffffffff: u'あ' + u'ぉ' * (8*2-1) + u'ぁ',
        0x10000000000000000: u'あた' + u'ぉ' * (8*2-1) + u'ぁ',
        0xffffffffffffffffffffffffffffffff: \
                u'あ' + u'ぉ' * (8*4-1) + u'ぁ',
        0x100000000000000000000000000000000: \
                u'あた' + u'ぉ' * (8*4-1) + u'ぁ',
        }

    code_len = {
            u'あ': 1,
            u'た': 1,
            u'ー': 1,
            u'っ': 2,
            u'ぁ': 3,
            u'ぉ': 4}

    def testencodeint(self):
        for i, s in self.intdata.iteritems():
            self.assertEqual(runlength.encode_int(i), s)

    def testdecodeint(self):
        for i, s in self.intdata.iteritems():
            self.assertEqual(runlength.decode_int(s), i)

    def testencodedecode(self):
        with open(__file__, 'rb') as f:
            data = f.read()
        s = runlength.encode(data)
        b = runlength.decode(s)

        code_len = self.code_len
        self.assertEqual(
                len(data) * 8,
                sum(code_len.get(c, 0) for c in s))
        self.assertEqual(data, b)

if __name__ == '__main__':
    unittest.main()
