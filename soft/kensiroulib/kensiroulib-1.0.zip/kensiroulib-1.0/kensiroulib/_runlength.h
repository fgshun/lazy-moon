/* KensirouEncoder object */
typedef struct {
    PyObject_HEAD
    Py_UNICODE code_on;
    Py_UNICODE code_off;
    Py_UNICODE code_repeat[4];
    unsigned char state;
    unsigned char count;
} KensirouEncoder_object;

static PyTypeObject KensirouEncoder_type;

static int
KensirouEncoder_init(KensirouEncoder_object *self, PyObject *args, PyObject *kwds);
static PyObject *
KensirouEncoder_iterencode(KensirouEncoder_object *self, PyObject *args, PyObject *kwds);
static PyObject *
KensirouEncoder_reset(KensirouEncoder_object *self, PyObject *args);

static PyObject *
KensirouEncoder_getcode_on(KensirouEncoder_object *self, void *closure);
static PyObject *
KensirouEncoder_getcode_off(KensirouEncoder_object *self, void *closure);
static PyObject *
KensirouEncoder_getcode_repeat(KensirouEncoder_object *self, void *closure);

/* KensirouDecoder object */
typedef struct {
    PyObject_HEAD
    Py_UNICODE *code_on;
    Py_ssize_t code_on_len;
    Py_UNICODE *code_off;
    Py_ssize_t code_off_len;
    Py_UNICODE code_repeat[4];
    unsigned char byte;
    Py_ssize_t decoded;
    unsigned char state;
    unsigned char count;
} KensirouDecoder_object;

static PyTypeObject KensirouDecoder_type;

static int
KensirouDecoder_init(KensirouDecoder_object *self, PyObject *args, PyObject *kwds);
static void
KensirouDecoder_dealloc(KensirouDecoder_object *self);
static PyObject *
KensirouDecoder_iterdecode(KensirouDecoder_object *self, PyObject *args, PyObject *kwds);
static PyObject *
KensirouDecoder_reset(KensirouDecoder_object *self, PyObject *args);

static PyObject *
KensirouDecoder_getcode_on(KensirouDecoder_object *self, void *closure);
static PyObject *
KensirouDecoder_getcode_off(KensirouDecoder_object *self, void *closure);
static PyObject *
KensirouDecoder_getcode_repeat(KensirouDecoder_object *self, void *closure);

/* IterEncode object */
typedef struct {
    PyObject_HEAD
    KensirouEncoder_object *parent;
    PyObject *pyinput;
    char *input;
    Py_ssize_t input_len;
    Py_ssize_t index_input;
    int final;
} IterEncoder_object;

static PyTypeObject IterEncoder_type;

static int
IterEncoder_init(IterEncoder_object *self, PyObject *args, PyObject *kwds);
static int
IterEncoder_clear(IterEncoder_object *self);
static void
IterEncoder_dealloc(IterEncoder_object *self);
static int
IterEncoder_traverse(IterEncoder_object *self, visitproc visit, void *arg);
static PyObject *
IterEncoder_next(IterEncoder_object *self);

/* IterDecoder object */
typedef struct {
    PyObject_HEAD
    KensirouDecoder_object *parent;
    PyUnicodeObject *pyinput;
    Py_UNICODE *input;
    Py_ssize_t input_len;
    Py_ssize_t index;
    int final;
} IterDecoder_object;

static PyTypeObject IterDecoder_type;

static int
IterDecoder_init(IterDecoder_object *self, PyObject *args, PyObject *kwds);
static int
IterDecoder_clear(IterDecoder_object *self);
static void
IterDecoder_dealloc(IterDecoder_object *self);
static int
IterDecoder_traverse(IterDecoder_object *self, visitproc visit, void *arg);
static PyObject *
IterDecoder_next(IterDecoder_object *self);
