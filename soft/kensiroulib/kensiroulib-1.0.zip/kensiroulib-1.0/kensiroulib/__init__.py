# coding: utf-8

import itertools

__all__ = ['ver1', 'ver2', 'runlength']

def int2bits(i):
    u"""数値をビット列に変換する
    
    ビットが立っていれば非 0 、立っていなければ 0 と変換する。
    速度を上げるため bool での変換などをかけていないが
    if 文などで真偽判定する分には問題はない。

    これが不満であれば
    (bool(bit) for bit in int2bits(b)) とさらにラップすればよい。
    """
    output = []
    mask = 1
    while i >= mask:
        output.append(i & mask)
        mask <<= 1

    output.reverse()
    return output
