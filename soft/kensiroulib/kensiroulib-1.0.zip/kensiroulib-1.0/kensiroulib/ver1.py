# coding: utf-8

ur"""ケンシロウ進数

オリジナル:
http://www.asahi-net.or.jp/~RC4T-ISHR/kensiro.html

解説:
ケンシロウ進数とは
『あ』を「1」に、『た』を「0」に当てはめた
口語による 2 進数の伝達法である。

   0: た
   1: あ
   2: あた
   3: ああ
   4: あたた
   5: あたあ
 512: あたたたたたたたたた
9344: あたたあたたあたたたたたたた

本来は口語による伝達手段として用いるものだが
常人には発声、聞き取りを行うことが困難である。
このモジュールは、常人がケンシロウ進数を
会得するまでの修行に用いるためのものである。

修行以外に用いてもかまわない。

使用法:
非負整数とケンシロウ進数の相互変換には
encode_int 関数および decode_int 関数を用いる。

>>> from kensiroulib import ver1
>>> atata = ver1.encode_int(2)
>>> print atata
あた
>>> ver1.decode_int(atata)
2

バイト列とケンシロウ進数の相互変換には
encode 関数および decode 関数を用いる。

>>> data = '\xf0\xaa'
>>> atata = ver1.encode(data)
>>> data == ver1.decode(atata)
True

また、変換対象を分割して入力することができる。
このためにはエンコーダ、デコーダインスタンスを作成し、
これの iterencode, iterdecode メソッドの input 引数に値を渡す。
final 引数には入力が終了した際は True, 
終了していない場合は False を渡すようにする。

>>> data1 = ver1.encode('abc')
>>> encoder = ver1.KensirouEncoder()
>>> data2 = []
>>> for byte in 'abc':
...   data2.extend(encoder.encode(byte, final=False))
... else:
...   data2.extend(encoder.encode('', final=True))
...
>>> data2 = u''.join(data2)
>>> data1 == data2
True

注意点:
このモジュールで復号を行う時には
『あ』、『た』以外の文字を無視する。
このため「あたたたたあたあたーーーっ」を 
0b10001010 に復号することは可能である。
"""

from kensiroulib import int2bits
from kensiroulib import _ver1

__all__ = [
        'KensirouEncoder', 'KensirouDecoder',
        'encode', 'decode', 'encode_int', 'decode_int']

class KensirouCoder(object):
    code_on = (u'あ',)
    code_off = (u'た',)

class KensirouEncoder(KensirouCoder):
    @classmethod
    def encode_int(cls, value):
        u"""非負整数をケンシロウ進数に変換する"""
        if value < 0:
            raise ValueError(
                    u'value must be >= 0, not {0}'.format(value))
        if value == 0:
            return cls.code_off[0]

        code_on = cls.code_on[0]
        code_off = cls.code_off[0]

        output = []
        for bit in int2bits(value):
            output.append(code_on if bit else code_off)

        return u''.join(output)

    def __init__(self):
        self._encoder = _ver1.KensirouEncoder(
                self.code_on[0], self.code_off[0])

    def iterencode(self, input, final=False):
        u"""バイト列 input をケンシロウ進数に変換するイテレータを返す

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return self._encoder.iterencode(input, final)

    def encode(self, input, final=False):
        u"""バイト列 input をケンシロウ進数に変換する

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return u''.join(self.iterencode(input, final))

    def reset(self):
        pass

    def getstate(self):
        return ()

    def setstate(self, state):
        pass

class KensirouDecoder(KensirouCoder):

    @classmethod
    def decode_int(cls, string):
        u"""ケンシロウ進数を非負整数に変換する"""
        if not isinstance(string, unicode):
            raise TypeError(u"can't decode '{0}' object".format(
                string.__class__.__name__))

        code_on = cls.code_on
        code_off = cls.code_off

        output = 0
        for c in string:
            if c in code_on:
                output <<= 1
                output += 1
            elif c in code_off:
                output <<= 1
            else:
                continue
        return output

    def __init__(self):
        self._decoder = _ver1.KensirouDecoder(self.code_on, self.code_off)

    def iterdecode(self, input, final=False):
        u"""ケンシロウ進数 input をバイト列に変換するイテレータを返す

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return self._decoder.iterdecode(input, final)

    def decode(self, input, final=False):
        u"""ケンシロウ進数 input をバイト列に変換する

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return ''.join(self.iterdecode(input, final))

    def reset(self):
        self._decoder.reset()

    def getstate(self):
        return self._decoder._byte, self._decoder._decoded

    def setstate(self, state):
        self._decoder._byte, self._decoder._decoded = state

_encode = KensirouEncoder().encode
def encode(bytes):
    return _encode(bytes, final=True)

_decode = KensirouDecoder().decode
def decode(string):
    return _decode(string, final=True)

encode_int = KensirouEncoder.encode_int
decode_int = KensirouDecoder.decode_int
