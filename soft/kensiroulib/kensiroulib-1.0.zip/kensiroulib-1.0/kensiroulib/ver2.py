# coding: utf-8

ur"""ケンシロウ進数2

オリジナル:
http://fumisa.haun.org/glossary/hokuto-radix.html

解説:
ケンシロウ進数2とは
『あ』および breath に状態遷移、
『た』に符号化の機能を持たせた
口語による 2 進数の伝達法である。

      2進数       ケンシロウ進数2の例
   0:          0 （技の構え）
   1:          1 あた
   2:         10 あた た
   3:         11 あたた
 143:   10001111 あた たたたあたたたた
 512: 1000000000 あた たたたたたたたたた
1023: 1111111111 あたたたたたたたたたた

本来は口語による伝達手段として用いるものだが
常人には発声、聞き取りを行うことが困難である。
このモジュールは、常人がケンシロウ進数を
会得するまでの修行に用いるためのものである。

修行以外に用いてもかまわない。

使用法:
非負整数とケンシロウ進数の相互変換には
encode_int 関数および decode_int 関数を用いる。

>>> from kensiroulib import ver2
>>> atata = ver2.encode_int(2)
>>> print atata
あた た
>>> ver2.decode_int(atata)
2

バイト列とケンシロウ進数の相互変換には
encode 関数および decode 関数を用いる。

>>> data = '\xf0\xaa'
>>> atata = ver2.encode(data)
>>> data == ver2.decode(atata)
True

また、変換対象を分割して入力することができる。
このためにはエンコーダ、デコーダインスタンスを作成し、
これの iterencode, iterdecode メソッドの input 引数に値を渡す。
final 引数には入力が終了した際は True, 
終了していない場合は False を渡すようにする。

>>> data1 = ver2.encode('abc')
>>> encoder = ver2.KensirouEncoder()
>>> data2 = []
>>> for byte in 'abc':
...   data2.extend(encoder.encode(byte, final=False))
... else:
...   data2.extend(encoder.encode('', final=True))
...
>>> data2 = u''.join(data2)
>>> data1 == data2
True

注意点:
breath は半角スペース(u'\u0020')で表現する。

このモジュールでは符号化を行うとき
01 の状態変化には『あ』、 10 は breath を用いる。
つまり、符号化した結果は一意となる。
たとえば、 10001111 は必ず「あた たたたあたたたた」となる。
しかし本来のケンシロウ進数2に則ると
「あたあたたた たたたた」としても誤りとはいえない。
ケンシロウ進数2では『あ』と breath に機能差はなく、
一つの値に複数の符号が対応することはある。

このモジュールで復号を行う時には
符号化の時とは異なり、『あ』と breath は同一とみなす。
「あた たたたあたたたた」、「あたあたたた たたたた」ともに
10001111 と復号できる。

このモジュールで復号を行う時には
『あ』、『た』、半角スペース以外の文字を無視する。
このため「あたーっ、あたたたあたたたた」を 
0b10001111 に復号することは可能である。
"""

from kensiroulib import int2bits
from kensiroulib import _ver2

__all__ = [
        'KensirouEncoder', 'KensirouDecoder',
        'encode', 'decode', 'encode_int', 'decode_int']

class KensirouCoder(object):
    code_coding = (u'た',)
    code_changing = (u'あ', u' ')

class KensirouEncoder(KensirouCoder):
    @classmethod
    def encode_int(cls, value):
        u"""非負整数をケンシロウ進数2に変換する"""
        if value < 0:
            raise ValueError(
                    u'value must be >= 0, not {0}'.format(value))
        if value == 0:
            return u''

        code_coding = cls.code_coding[0]
        code_changing0 = cls.code_changing[0]
        code_changing1 = cls.code_changing[1]

        output = []
        state = 0
        for bit in int2bits(value):
            if bit:
                if not state:
                    output.append(code_changing0)
                    state = 1
            else:
                if state:
                    output.append(code_changing1)
                    state = 0
            output.append(code_coding)

        return u''.join(output)

    def __init__(self):
        self._encoder = _ver2.KensirouEncoder(
                self.code_coding[0], self.code_changing[0:2])

    def iterencode(self, input, final=False):
        u"""バイト列 input をケンシロウ進数2に変換するイテレータを返す

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return self._encoder.iterencode(input, final)

    def encode(self, input, final=False):
        u"""バイト列 input をケンシロウ進数2に変換する

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return u''.join(self.iterencode(input, final))

    def reset(self):
        return self._encoder.reset()

    def getstate(self):
        return self._encoder._state,

    def setstate(self, state):
        self._encoder._state, = state

class KensirouDecoder(KensirouCoder):
    @classmethod
    def decode_int(cls, string):
        u"""ケンシロウ進数2を非負整数に変換する"""
        if not isinstance(string, unicode):
            raise TypeError(u"can't decode '{0}' object".format(
                string.__class__.__name__))

        code_coding = cls.code_coding
        code_changing = cls.code_changing

        output = 0
        state = 0
        for c in string:
            if c in code_coding:
                output <<= 1
                output += state
            elif c in code_changing:
                state ^= 1
            else:
                continue
        return output

    def __init__(self):
        self._decoder = _ver2.KensirouDecoder(
                self.code_coding, self.code_changing)

    def iterdecode(self, input, final=False):
        u"""ケンシロウ進数2 input をバイト列に変換するイテレータを返す

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return self._decoder.iterdecode(input, final)

    def decode(self, input, final=False):
        u"""ケンシロウ進数2 input をバイト列に変換する

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return ''.join(self.iterdecode(input, final))

    def reset(self):
        self._decoder.reset()

    def getstate(self):
        return (self._decoder._byte,
                self._decoder._decoded,
                self._decoder._state)

    def setstate(self, state):
        (self._decoder._byte,
         self._decoder._decoded,
         self._decoder._state) = state

_encode = KensirouEncoder().encode
def encode(bytes):
    return _encode(bytes, final=True)

_decode = KensirouDecoder().decode
def decode(string):
    return _decode(string, final=True)

encode_int = KensirouEncoder.encode_int
decode_int = KensirouDecoder.decode_int
