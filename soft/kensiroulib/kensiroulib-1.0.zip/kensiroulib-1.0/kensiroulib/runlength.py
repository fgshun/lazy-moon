# coding: utf-8
ur"""ランレングス圧縮版ケンシロウ進数

オリジナル:
http://msuzuki-program.hp.infoseek.co.jp/MEMO/MEMOC.html#20011126

解説:
ケンシロウ進数とは
『あ』を「1」に、『た』を「0」に当てはめた
口語による 2 進数の伝達法である。
しかし、大量データの転送には不向きがあるため
圧縮を試みたものがランレングス圧縮版ケンシロウ進数である。

      2進数         ケンシロウ進数        ランレングス圧縮ケンシロウ進数
   0           0    た                    た
   1           1    あ                    あ
   2          10    あた                  あた
   3          11    ああ                  あー
   4         100    あたた                あたー
   5         101    あたあ                あたあ
   6         110    ああた                あーた
   7         111    あああ                あっ
   8        1000    あたたた              あたっ
   9        1001    あたたあ              あたーあ
  10        1010    あたあた              あたあた
 100     1100100    ああたたあたた        あーたーあたー
 200    11001000    ああたたあたたた      あーたーあたっ
 300   100101100    あたたあたああたた    あたーあたあーたー
 500   111110100    あああああたあたた    あぉたあたー
1000  1111101000    あああああたあたたた  あぉたあたっ

つまり
『ー』: 直前の繰り返し
『っ』: 直前の繰り返し x2
『ぁ』: 直前の繰り返し x3
『ぉ』: 直前の繰り返し x4
である。

本来は口語による伝達手段として用いるものだが
常人には発生、聞き取りを行うことが困難である。
このモジュールは、常人がランレングス圧縮版ケンシロウ進数を
会得するまでの修行に用いるためのものである。

修行以外に用いてもかまわない。

使用法:
非負整数とケンシロウ進数の相互変換には
encode_int 関数および decode_int 関数を用いる。

>>> from kensiroulib import runlength
>>> atata = runlength.encode_int(2)
>>> print atata
あた
>>> runlength.decode_int(atata)
2

バイト列とケンシロウ進数の相互変換には
encode 関数および decode 関数を用いる。

>>> data = '\xf0\xaa'
>>> atata = runlength.encode(data)
>>> data == runlength.decode(atata)
True

また、変換対象を分割して入力することができる。
このためにはエンコーダ、デコーダインスタンスを作成し、
これの iterencode, iterdecode メソッドの input 引数に値を渡す。
final 引数には入力が終了した際は True, 
終了していない場合は False を渡すようにする。

>>> data1 = runlength.encode('abc')
>>> encoder = runlength.KensirouEncoder()
>>> data2 = []
>>> for byte in 'abc':
...   data2.extend(encoder.encode(byte, final=False))
... else:
...   data2.extend(encoder.encode('', final=True))
...
>>> data2 = u''.join(data2)
>>> data1 == data2
True

注意点:
このモジュールで復号を行う時には
『あ』、『た』、『－』、『っ』、『ぁ』、『ぉ』以外の文字を無視する。
このため「あたぁ！ お前はもう死んでいる。」を
0b10000 に復号することは可能である。
"""

import itertools

from kensiroulib import int2bits
from kensiroulib import _runlength

__all__ = [
        'KensirouEncoder', 'KensirouDecoder',
        'encode', 'decode', 'encode_int', 'decode_int']

class KensirouCoder(object):
    code_on = (u'あ',)
    code_off = (u'た',)
    code_repeat = {1: u'ー', 2: u'っ', 3: u'ぁ' , 4: u'ぉ'}

class KensirouEncoder(KensirouCoder):
    @classmethod
    def encode_int(cls, value):
        u"""非負整数をランレングス圧縮版ケンシロウ進数に変換する"""
        if value < 0:
            raise ValueError(
                    u'value must be >= 0, not {0}'.format(value))
        if value == 0:
            return cls.code_off[0]

        code_on = cls.code_on[0]
        code_off = cls.code_off[0]
        code_repeat = cls.code_repeat

        output = []
        state = 0
        count = 0
        for bit in int2bits(value):
            if bit:
                # ビットが立っている
                if state:
                    # 前回も立っている
                    if count == 3:
                        # 同符号4回目
                        output.append(code_repeat[4])
                        count = 0
                    else:
                        # 同符号1, 2, 3回目
                        count += 1
                else:
                    # 前回は立っていない
                    if count:
                        # 直前の繰り返しあり
                        output.append(code_repeat[count])
                    output.append(code_on)
                    state = 1
                    count = 0
            else:
                # ビットが立っていない
                if not state:
                    # 前回も立っていない
                    if count == 3:
                        # 同符号4回目
                        output.append(code_repeat[4])
                        count = 0
                    else:
                        # 同符号 1, 2, 3 回目
                        count += 1
                else:
                    # 前回は立っている
                    if count:
                        # 直前の繰り返しあり
                        output.append(code_repeat[count])
                    output.append(code_off)
                    state = 0
                    count = 0
        if count:
            output.append(code_repeat[count])
        return u''.join(output)

    def __init__(self):
        self._encoder = _runlength.KensirouEncoder(
                self.code_on[0], self.code_off[0], self.code_repeat)

    def iterencode(self, input, final=False):
        u"""ランレングス圧縮版ケンシロウ進数に変換するイテレータを返す

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return self._encoder.iterencode(input, final)

    def encode(self, input, final=False):
        u"""バイト列 input をランレングス圧縮版ケンシロウ進数に変換する

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return u''.join(self.iterencode(input, final))

    def reset(self):
        self._encoder.reset()

    def getstate(self):
        return self._encoder._state, self._encoder._count

    def setstate(self, state):
        self._encoder._state, self._encoder._count = state

class KensirouDecoder(KensirouCoder):
    @classmethod
    def decode_int(cls, string):
        u"""ランレングス圧縮版ケンシロウ進数を非負整数に変換する"""
        if not isinstance(string, unicode):
            raise TypeError(u"can't decode '{0}' object".format(
                string.__class__.__name__))

        code_on = cls.code_on
        code_off = cls.code_off
        code_repeat = dict((v, k) for k, v in cls.code_repeat.iteritems())

        output = 0
        state = 0
        count = 0
        for c in string:
            if c in code_on:
                state = 1
                count = 1
            elif c in code_off:
                state = 0
                count = 1
            elif c in code_repeat:
                count = code_repeat[c]
            else:
                continue
            for _ in itertools.repeat(None, count):
                output <<= 1
                output += state
        return output

    def __init__(self):
        self._decoder = _runlength.KensirouDecoder(
                self.code_on, self.code_off, self.code_repeat)

    def iterdecode(self, input, final=False):
        u"""ランレングス圧縮版ケンシロウ進数を変換するイテレータを返す

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return self._decoder.iterdecode(input, final)

    def decode(self, input, final=False):
        u"""ランレングス圧縮版ケンシロウ進数 input をバイト列に変換する

        final 引数は入力が終了していない場合は False,
        終了した場合は True にする。
        """
        return ''.join(self.iterdecode(input, final))

    def reset(self):
        self._decoder.reset()

    def getstate(self):
        return self._decoder._byte, self._decoder._decoded, self._decoder._state

    def setstate(self, state):
        self._decoder._byte, self._decoder._decoded, self._decoder._state = state

_encode = KensirouEncoder().encode
def encode(bytes):
    return _encode(bytes, final=True)

_decode = KensirouDecoder().decode
def decode(string):
    return _decode(string, final=True)

encode_int = KensirouEncoder.encode_int
decode_int = KensirouDecoder.decode_int
