#include <Python.h>
#include <structmember.h>

#include "_runlength.h"

/* KensirouEncoder object */
static int
KensirouEncoder_init(KensirouEncoder_object *self, PyObject *args, PyObject *kwds) {
    PyObject *code_on, *code_off, *code_repeat, *pyi, *u1;
    int i;

    static char *kwlist[] = {"code_on", "code_off", "code_repeat", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwds, "UUO", kwlist, &code_on, &code_off, &code_repeat)) {
        return -1;
    }

    if (PyUnicode_GET_SIZE(code_on) != 1) {
        return -1;
    }
    self->code_on = PyUnicode_AS_UNICODE(code_on)[0];

    if (PyUnicode_GET_SIZE(code_off) != 1) {
        return -1;
    }
    self->code_off = PyUnicode_AS_UNICODE(code_off)[0];

    if (!PyDict_Check(code_repeat)) {
        return -1;
    }
    for (i=0; i<4; i++) {
        pyi = PyInt_FromLong(i+1);
        u1 = PyDict_GetItem(code_repeat, pyi);
        if (u1 == NULL) {
            PyErr_SetString(PyExc_KeyError, "code_repeat don't have key of int");
            Py_DECREF(pyi);
            return -1;
        }
        if (!PyUnicode_Check(u1) || PyUnicode_GET_SIZE(u1) != 1) {
            PyErr_SetString(PyExc_KeyError, "code_repeat's item isn't unicode");
            Py_DECREF(pyi);
            return -1;
        }
        self->code_repeat[i] = PyUnicode_AS_UNICODE(u1)[0];
        Py_DECREF(pyi);
    }

    self->state = 0;
    self->count = 0;

    return 0;
}

static PyObject *
KensirouEncoder_iterencode(KensirouEncoder_object *self, PyObject *args, PyObject *kwds) {

    PyObject *input, *final;
    PyObject *iter;

    static char *kwlist[] = {
        "input", "final", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwds, "SO", kwlist, &input, &final)) {
        return NULL;
    }

    iter = PyObject_CallFunctionObjArgs(
            (PyObject *)(&IterEncoder_type),
            self, input, final, NULL);
    return iter;
}

static PyObject *
KensirouEncoder_reset(KensirouEncoder_object *self, PyObject *args) {
    self->state = 0;
    self->count = 0;

    Py_RETURN_NONE;
}

static PyMethodDef KensirouEncoder_methods[] = {
    {"iterencode", (PyCFunction)KensirouEncoder_iterencode,
        METH_VARARGS | METH_KEYWORDS},
    {"reset", (PyCFunction)KensirouEncoder_reset,
        METH_NOARGS},
    {NULL, NULL} /* sentinel */
};

static PyMemberDef KensirouEncoder_members[] = {
    {"_state", T_UBYTE, offsetof(KensirouEncoder_object, state), 0},
    {"_count", T_UBYTE, offsetof(KensirouEncoder_object, count), 0},
    {NULL}
};

static PyObject *
KensirouEncoder_getcode_on(KensirouEncoder_object *self, void *closure) {
    PyObject *result;
    
    result = PyUnicode_FromUnicode(&(self->code_on), 1);
    return result;
}

static PyObject *
KensirouEncoder_getcode_off(KensirouEncoder_object *self, void *closure) {
    PyObject *result;
    
    result = PyUnicode_FromUnicode(&(self->code_off), 1);
    return result;
}

static PyObject *
KensirouEncoder_getcode_repeat(KensirouEncoder_object *self, void *closure) {
    PyObject *result;
    
    result = PyUnicode_FromUnicode(self->code_repeat, 4);
    return result;
}

static PyGetSetDef KensirouEncoder_getseters[] = {
    {"_code_on", (getter)KensirouEncoder_getcode_on, NULL},
    {"_code_off", (getter)KensirouEncoder_getcode_off, NULL},
    {"_code_repeat", (getter)KensirouEncoder_getcode_repeat, NULL},
    {NULL}
};

static PyTypeObject KensirouEncoder_type = {
    PyObject_HEAD_INIT(NULL)
    0,                          /* ob_size */
    "kensiroulib._runlength.KensirouEncoder", /* tp_name */
    sizeof(KensirouEncoder_object),   /* tp_basicsize */
    0,                          /* tp_itemsize */
    /* methods */
    0,                          /* tp_dealloc */
    0,                          /* tp_print */
    0,                          /* tp_getattr */
    0,                          /* tp_setattr */
    0,                          /* tp_compare */
    0,                          /* tp_repr */
    0,                          /* tp_as_number */
    0,                          /* tp_as_sequence */
    0,                          /* tp_as_mapping */
    0,                          /* tp_hash */
    0,                          /* tp_call */
    0,                          /* tp_str */
    PyObject_GenericGetAttr,    /* tp_getattro */
    0,                          /* tp_setattro */
    0,                          /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE, /* tp_flags */
    0,                          /* tp_doc */
    0,                          /* tp_traverse */
    0,                          /* tp_clear */
    0,                          /* tp_richcompare */
    0,                          /* tp_weaklistoffset */
    0,                          /* tp_iter */
    0,                          /* tp_iternext */
    KensirouEncoder_methods,    /* tp_methods */
    KensirouEncoder_members,    /* tp_members */
    KensirouEncoder_getseters,  /* tp_getset */
    0,                          /* tp_base */
    0,                          /* tp_dict */
    0,                          /* tp_descr_get */
    0,                          /* tp_descr_set */
    0,                          /* tp_dictoffset */
    (initproc)KensirouEncoder_init,  /* tp_init */
    0,                          /* tp_alloc */
    0,                          /* tp_new */
    0,                          /* tp_free */
};

/* KensirouDecoder object */
static int
KensirouDecoder_init(KensirouDecoder_object *self, PyObject *args, PyObject *kwds) {
    PyObject *fast, *u1, *pyi;
    PyObject *code_on, *code_off, *code_repeat;
    int i;
    Py_ssize_t code_on_len, code_off_len;

    static char *kwlist[] = {"code_on", "code_off", "code_repeat", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwds, "OOO", kwlist, &code_on, &code_off, &code_repeat)) {
        return -1;
    }

    PyMem_Del(self->code_on);
    self->code_on = NULL;
    PyMem_Del(self->code_off);
    self->code_off = NULL;

    fast = PySequence_Fast(code_on, "code_on is not sequence");
    if (fast == NULL) {
        return -1;
    }
    code_on_len = PySequence_Fast_GET_SIZE(fast);
    self->code_on = PyMem_NEW(Py_UNICODE, code_on_len);
    if (self->code_on == NULL) {
        Py_DECREF(fast);
        return -1;
    }
    for (i=0; i<code_on_len; i++) {
        u1 = PySequence_ITEM(fast, i);
        if (!PyUnicode_Check(u1) || PyUnicode_GET_SIZE(u1) != 1) {
            Py_DECREF(fast);
            PyMem_Del(self->code_on);
            self->code_on = NULL;
            return -1;
        }
        self->code_on[i] = PyUnicode_AS_UNICODE(u1)[0];
    }
    Py_DECREF(fast);

    fast = PySequence_Fast(code_off, "code_off is not sequence");
    if (fast == NULL) {
        return -1;
    }
    code_off_len = PySequence_Fast_GET_SIZE(fast);
    self->code_off = PyMem_NEW(Py_UNICODE, code_off_len);
    if (self->code_off == NULL) {
        Py_DECREF(fast);
        PyMem_Del(self->code_on);
        self->code_on = NULL;
        return -1;
    }
    for (i=0; i<code_off_len; i++) {
        u1 = PySequence_ITEM(fast, i);
        if (!PyUnicode_Check(u1) || PyUnicode_GET_SIZE(u1) != 1) {
            Py_DECREF(fast);
            PyMem_Del(self->code_on);
            self->code_on = NULL;
            PyMem_Del(self->code_off);
            self->code_off = NULL;
            return -1;
        }
        self->code_off[i] = PyUnicode_AS_UNICODE(u1)[0];
    }
    Py_DECREF(fast);

    if (!PyDict_Check(code_repeat)) {
        PyMem_Del(self->code_on);
        self->code_on = NULL;
        PyMem_Del(self->code_off);
        self->code_off = NULL;
        return -1;
    }
    for (i=0; i<4; i++) {
        pyi = PyInt_FromLong(i+1);
        if (pyi == NULL) {
            PyMem_Del(self->code_on);
            self->code_on = NULL;
            PyMem_Del(self->code_off);
            self->code_off = NULL;
        }
        u1 = PyDict_GetItem(code_repeat, pyi);
        if (u1 == NULL) {
            PyMem_Del(self->code_on);
            self->code_on = NULL;
            PyMem_Del(self->code_off);
            self->code_off = NULL;
            PyErr_SetString(PyExc_KeyError, "code_repeat don't have key of int");
            Py_DECREF(pyi);
            return -1;
        }
        if (!PyUnicode_Check(u1) || PyUnicode_GET_SIZE(u1) != 1) {
            PyMem_Del(self->code_on);
            self->code_on = NULL;
            PyMem_Del(self->code_off);
            self->code_off = NULL;
            PyErr_SetString(PyExc_KeyError, "code_repeat's item isn't unicode");
            Py_DECREF(pyi);
            return -1;
        }
        self->code_repeat[i] = PyUnicode_AS_UNICODE(u1)[0];
        Py_DECREF(pyi);
    }

    self->code_on_len = code_on_len;
    self->code_off_len = code_off_len;
    self->byte = 0;
    self->decoded = 0;
    self->state = 0;
    self->count = 0;

    return 0;
}

static void
KensirouDecoder_dealloc(KensirouDecoder_object *self)
{
    PyMem_Del(self->code_on);
    self->code_on = NULL;
    PyMem_Del(self->code_off);
    self->code_off = NULL;
    Py_TYPE(self)->tp_free(self);
}

static PyObject *
KensirouDecoder_iterdecode(KensirouDecoder_object *self, PyObject *args, PyObject *kwds) {

    PyObject *input, *final;
    PyObject *iter;

    static char *kwlist[] = {
        "input", "final", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwds, "UO", kwlist, &input, &final)) {
        return NULL;
    }

    iter = PyObject_CallFunctionObjArgs(
            (PyObject *)(&IterDecoder_type),
            self, input, final, NULL);
    return iter;
}

static PyObject *
KensirouDecoder_reset(KensirouDecoder_object *self, PyObject *args) {
    self->byte = 0;
    self->decoded = 0;
    self->state = 0;
    self->count = 0;

    Py_RETURN_NONE;
}

static PyMethodDef KensirouDecoder_methods[] = {
    {"iterdecode", (PyCFunction)KensirouDecoder_iterdecode,
        METH_VARARGS | METH_KEYWORDS},
    {"reset", (PyCFunction)KensirouDecoder_reset,
        METH_NOARGS},
    {NULL, NULL} /* sentinel */
};

static PyMemberDef KensirouDecoder_members[] = {
    {"_byte", T_PYSSIZET, offsetof(KensirouDecoder_object, byte), 0},
    {"_decoded", T_UBYTE, offsetof(KensirouDecoder_object, decoded), 0},
    {"_state", T_UBYTE, offsetof(KensirouDecoder_object, state), 0},
    {"_count", T_UBYTE, offsetof(KensirouDecoder_object, count), 0},
    {NULL}
};

static PyObject *
KensirouDecoder_getcode_on(KensirouDecoder_object *self, void *closure) {
    return PyUnicode_FromUnicode(self->code_on, self->code_on_len);
}

static PyObject *
KensirouDecoder_getcode_off(KensirouDecoder_object *self, void *closure) {
    return PyUnicode_FromUnicode(self->code_off, self->code_off_len);
}

static PyObject *
KensirouDecoder_getcode_repeat(KensirouDecoder_object *self, void *closure) {
    return PyUnicode_FromUnicode(self->code_repeat, 4);
}

static PyGetSetDef KensirouDecoder_getseters[] = {
    {"_code_on", (getter)KensirouDecoder_getcode_on, NULL},
    {"_code_off", (getter)KensirouDecoder_getcode_off, NULL},
    {"_code_repeat", (getter)KensirouDecoder_getcode_repeat, NULL},
    {NULL}
};

static PyTypeObject KensirouDecoder_type = {
    PyObject_HEAD_INIT(NULL)
    0,                          /* ob_size */
    "kensiroulib._runlength.KensirouDecoder", /* tp_name */
    sizeof(KensirouDecoder_object),   /* tp_basicsize */
    0,                          /* tp_itemsize */
    /* methods */
    (destructor)KensirouDecoder_dealloc, /* tp_dealloc */
    0,                          /* tp_print */
    0,                          /* tp_getattr */
    0,                          /* tp_setattr */
    0,                          /* tp_compare */
    0,                          /* tp_repr */
    0,                          /* tp_as_number */
    0,                          /* tp_as_sequence */
    0,                          /* tp_as_mapping */
    0,                          /* tp_hash */
    0,                          /* tp_call */
    0,                          /* tp_str */
    PyObject_GenericGetAttr,    /* tp_getattro */
    0,                          /* tp_setattro */
    0,                          /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE, /* tp_flags */
    0,                          /* tp_doc */
    0,                          /* tp_traverse */
    0,                          /* tp_clear */
    0,                          /* tp_richcompare */
    0,                          /* tp_weaklistoffset */
    0,                          /* tp_iter */
    0,                          /* tp_iternext */
    KensirouDecoder_methods,    /* tp_methods */
    KensirouDecoder_members,    /* tp_members */
    KensirouDecoder_getseters,  /* tp_getset */
    0,                          /* tp_base */
    0,                          /* tp_dict */
    0,                          /* tp_descr_get */
    0,                          /* tp_descr_set */
    0,                          /* tp_dictoffset */
    (initproc)KensirouDecoder_init,  /* tp_init */
    0,                          /* tp_alloc */
    0,                          /* tp_new */
    0,                          /* tp_free */
};

/* IterEncoder object */
static int
IterEncoder_init(IterEncoder_object *self, PyObject *args, PyObject *kwds) {
    PyObject *parent, *pyinput;
    PyObject *temp;
    int final;

    static char *kwlist[] = {"parent", "input", "final", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwds, "OSI", kwlist,
                &parent, &pyinput, &final)) {
        return -1;
    }

    temp = (PyObject *)self->parent;
    Py_INCREF(parent);
    self->parent = (KensirouEncoder_object *)parent;
    Py_XDECREF(temp);

    Py_INCREF(pyinput);
    self->pyinput = pyinput;
    PyString_AsStringAndSize(self->pyinput, &self->input, &self->input_len);

    self->index_input = 0;
    self->final = final;
    return 0;
}

static int
IterEncoder_clear(IterEncoder_object *self)
{
    Py_CLEAR(self->parent);
    Py_CLEAR(self->pyinput);
    return 0;
}

static void
IterEncoder_dealloc(IterEncoder_object *self)
{
    PyObject_GC_UnTrack(self);
    IterEncoder_clear(self);
    Py_TYPE(self)->tp_free((PyObject *)self);
}

static int
IterEncoder_traverse(IterEncoder_object *self, visitproc visit, void *arg)
{
    Py_VISIT(self->parent);
    Py_VISIT(self->pyinput);
    return 0;
}

static PyObject *
IterEncoder_next(IterEncoder_object *self)
{
    PyObject *result;
    Py_UNICODE temp[16]; /* temp[9] �ł�����Ă���H */
    Py_UNICODE code_on, code_off, *code_repeat;
    char *input;
    Py_ssize_t input_len, *index_input;
    unsigned char bit_mask, result_len, *state, *count;

    code_on = self->parent->code_on;
    code_off = self->parent->code_off;
    code_repeat = self->parent->code_repeat;
    state = &(self->parent->state);
    count = &(self->parent->count);

    input = self->input;
    input_len = self->input_len;
    index_input = &(self->index_input);

    result_len = 0;

    if (*index_input >= input_len) {
        if (self->final) {
            if (*count) {
                temp[result_len] = code_repeat[*count - 1];
                *count = 0;
                ++result_len;
                result = PyUnicode_FromUnicode(temp, result_len);
            }
            else {
                Py_XDECREF(PyObject_CallMethod(
                        (PyObject *)self->parent, "reset", NULL));
                result = NULL;
            }
        }
        else {
            result = NULL;
        }
    }
    else {
        for (bit_mask=1 << 7; bit_mask>0; bit_mask >>= 1) {
            if (input[*index_input] & bit_mask) {
                if (*state) {
                    ++(*count);
                    if (*count == 4) {
                        temp[result_len] = code_repeat[*count -1];
                        *count = 0;
                        ++result_len;
                    }
                }
                else {
                    if (*count) {
                        temp[result_len] = code_repeat[*count - 1];
                        ++result_len;
                    }
                    temp[result_len] = code_on;
                    ++result_len;
                    *state ^= 1;
                    *count = 0;
                }
            }
            else {
                if (!(*state)) {
                    ++(*count);
                    if (*count == 4) {
                        temp[result_len] = code_repeat[*count -1];
                        *count = 0;
                        ++result_len;
                    }
                }
                else {
                    if (*count) {
                        temp[result_len] = code_repeat[*count - 1];
                        ++result_len;
                    }
                    temp[result_len] = code_off;
                    ++result_len;
                    *state ^= 1;
                    *count = 0;
                }
            }
        }

        ++(*index_input);

        result = PyUnicode_FromUnicode(temp, result_len);
    }

    return result;
}

static PyMethodDef IterEncoder_methods[] = {
    {NULL, NULL} /* sentinel */
};

static PyTypeObject IterEncoder_type = {
    PyObject_HEAD_INIT(NULL)
    0,                          /* ob_size */
    "kensiroulib._runlength.IterEncoder", /* tp_name */
    sizeof(IterEncoder_object),   /* tp_basicsize */
    0,                          /* tp_itemsize */
    /* methods */
    (destructor)IterEncoder_dealloc, /* tp_dealloc */
    0,                          /* tp_print */
    0,                          /* tp_getattr */
    0,                          /* tp_setattr */
    0,                          /* tp_compare */
    0,                          /* tp_repr */
    0,                          /* tp_as_number */
    0,                          /* tp_as_sequence */
    0,                          /* tp_as_mapping */
    0,                          /* tp_hash */
    0,                          /* tp_call */
    0,                          /* tp_str */
    PyObject_GenericGetAttr,    /* tp_getattro */
    0,                          /* tp_setattro */
    0,                          /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HAVE_GC |
        Py_TPFLAGS_BASETYPE,    /* tp_flags */
    0,                          /* tp_doc */
    (traverseproc)IterEncoder_traverse, /* tp_traverse */
    (inquiry)IterEncoder_clear, /* tp_clear */
    0,                          /* tp_richcompare */
    0,                          /* tp_weaklistoffset */
    PyObject_SelfIter,          /* tp_iter */
    (iternextfunc)IterEncoder_next,  /* tp_iternext */
    IterEncoder_methods,        /* tp_methods */
    0,                          /* tp_members */
    0,                          /* tp_getset */
    0,                          /* tp_base */
    0,                          /* tp_dict */
    0,                          /* tp_descr_get */
    0,                          /* tp_descr_set */
    0,                          /* tp_dictoffset */
    (initproc)IterEncoder_init, /* tp_init */
    0,                          /* tp_alloc */
    0,                          /* tp_new */
    0,                          /* tp_free */
};

/* IterDecoder object */
static int
IterDecoder_init(IterDecoder_object *self, PyObject *args, PyObject *kwds) {
    PyObject *parent, *pyinput;
    PyObject *temp;
    int final;

    static char *kwlist[] = {
        "parent", "input", "final", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwds, "OUI", kwlist,
                &parent, &pyinput, &final)) {
        return -1;
    }

    temp = (PyObject *)self->parent;
    Py_INCREF(parent);
    self->parent = (KensirouDecoder_object *)parent;
    Py_XDECREF(temp);

    temp = (PyObject *)self->pyinput;
    Py_INCREF(pyinput);
    self->pyinput = (PyUnicodeObject *)pyinput;
    Py_XDECREF(temp);

    self->input = PyUnicode_AS_UNICODE(self->pyinput);
    self->input_len = PyUnicode_GET_SIZE(self->pyinput);
    self->index = 0;
    self->final = final;

    return 0;
}

static int
IterDecoder_clear(IterDecoder_object *self)
{
    Py_CLEAR(self->parent);
    Py_CLEAR(self->pyinput);
    return 0;
}

static void
IterDecoder_dealloc(IterDecoder_object *self)
{
    PyObject_GC_UnTrack(self);
    IterDecoder_clear(self);
    Py_TYPE(self)->tp_free((PyObject *)self);
}

static int
IterDecoder_traverse(IterDecoder_object *self, visitproc visit, void *arg)
{
    Py_VISIT(self->parent);
    Py_VISIT(self->pyinput);
    return 0;
}

static PyObject *
IterDecoder_next(IterDecoder_object *self)
{
    PyObject *result;
    Py_UNICODE *code_on, *code_off, *code_repeat, *input;
    Py_ssize_t code_on_len, code_off_len, *decoded, input_len, *index;
    unsigned char *byte, *state, *count;
    int i, j, k;

    code_on = self->parent->code_on;
    code_off = self->parent->code_off;
    code_repeat = self->parent->code_repeat;
    code_on_len = self->parent->code_on_len;
    code_off_len = self->parent->code_off_len;
    decoded = &(self->parent->decoded);
    byte = &(self->parent->byte);
    state = &(self->parent->state);
    count = &(self->parent->count);

    input = self->input;
    input_len = self->input_len;
    index = &(self->index);

    if (*index >= input_len) {
        if (self->final) {
            if (*decoded) {
                PyErr_SetString(PyExc_ValueError, "incomplete data.");
            }
            Py_XDECREF(PyObject_CallMethod(
                    (PyObject *)self->parent, "reset", NULL));
        }
        result = NULL;
    }
    else {
        while (*index < input_len) {
            if (!(*count)) {
                for (i=0; i < code_on_len; i++) {
                    if (input[*index] == code_on[i]) {
                        *state = 1;
                        *count = 1;
                        break;
                    }
                }
                if (i >= code_on_len) {
                    for (j=0; j < code_off_len; j++) {
                        if (input[*index] == code_off[j]) {
                            *state = 0;
                            *count = 1;
                            break;
                        }
                    }
                }
                if (i >= code_on_len && i>=code_off_len) {
                    for (k=0; k < 4; k++) {
                        if (input[*index] == code_repeat[k]) {
                            *count = k + 1;
                            break;
                            }
                    }
                }

                ++(*index);
            }

            while (*count) {
                *count -= 1;
                *byte <<= 1;
                *byte += *state;
                if (*decoded < 7) {
                    *decoded += 1;
                }
                else {
                    *decoded = 0;
                    break;
                }
            }

            if ((*decoded) == 0) {
                break;
            }

        }

        if (*decoded) {
            result = PyString_FromString("");
        }
        else {
            result = PyString_FromStringAndSize(byte, 1);
            *byte = 0;
        }
    }

    return result;
}

static PyMethodDef IterDecoder_methods[] = {
    {NULL, NULL} /* sentinel */
};

static PyMemberDef IterDecoder_members[] = {
    {"_parent", T_OBJECT_EX, offsetof(IterDecoder_object, parent), READONLY},
    {"_input", T_OBJECT_EX, offsetof(IterDecoder_object, pyinput), READONLY},
    {"_index", T_PYSSIZET, offsetof(IterDecoder_object, index), READONLY},
    {NULL} /* sentinel */
};

static PyTypeObject IterDecoder_type = {
    PyObject_HEAD_INIT(NULL)
    0,                          /* ob_size */
    "kensiroulib._runlength.iterdecode", /* tp_name */
    sizeof(IterDecoder_object), /* tp_basicsize */
    0,                          /* tp_itemsize */
    /* methods */
    (destructor)IterDecoder_dealloc, /* tp_dealloc */
    0,                          /* tp_print */
    0,                          /* tp_getattr */
    0,                          /* tp_setattr */
    0,                          /* tp_compare */
    0,                          /* tp_repr */
    0,                          /* tp_as_number */
    0,                          /* tp_as_sequence */
    0,                          /* tp_as_mapping */
    0,                          /* tp_hash */
    0,                          /* tp_call */
    0,                          /* tp_str */
    PyObject_GenericGetAttr,    /* tp_getattro */
    0,                          /* tp_setattro */
    0,                          /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HAVE_GC |
        Py_TPFLAGS_BASETYPE,    /* tp_flags */
    0,                          /* tp_doc */
    (traverseproc)IterDecoder_traverse, /* tp_traverse */
    (inquiry)IterDecoder_clear, /* tp_clear */
    0,                          /* tp_richcompare */
    0,                          /* tp_weaklistoffset */
    PyObject_SelfIter,          /* tp_iter */
    (iternextfunc)IterDecoder_next, /* tp_iternext */
    IterDecoder_methods,        /* tp_methods */
    IterDecoder_members,        /* tp_members */
    0,                          /* tp_getset */
    0,                          /* tp_base */
    0,                          /* tp_dict */
    0,                          /* tp_descr_get */
    0,                          /* tp_descr_set */
    0,                          /* tp_dictoffset */
    (initproc)IterDecoder_init, /* tp_init */
    0,                          /* tp_alloc */
    0,                          /* tp_new */
    0,                          /* tp_free */
};

static PyMethodDef module_methods[] = {
    {NULL, NULL, 0, NULL} /* Sentinel */
};

PyMODINIT_FUNC
init_runlength(void)
{
    PyObject* m;

    m = Py_InitModule3("_runlength", module_methods,
            "Atatatatata.");
    if (m == NULL)
        return;

    KensirouEncoder_type.tp_new = PyType_GenericNew;
    if (PyType_Ready(&KensirouEncoder_type) < 0)
        return;
    Py_INCREF(&KensirouEncoder_type);
    PyModule_AddObject(
            m, "KensirouEncoder", (PyObject *)&KensirouEncoder_type);

    KensirouDecoder_type.tp_new = PyType_GenericNew;
    if (PyType_Ready(&KensirouDecoder_type) < 0)
        return;
    Py_INCREF(&KensirouDecoder_type);
    PyModule_AddObject(
            m, "KensirouDecoder", (PyObject *)&KensirouDecoder_type);

    IterEncoder_type.tp_new = PyType_GenericNew;
    if (PyType_Ready(&IterEncoder_type) < 0)
        return;
    Py_INCREF(&IterEncoder_type);
    PyModule_AddObject(
            m, "IterEncoder", (PyObject *)&IterEncoder_type);

    IterDecoder_type.tp_new = PyType_GenericNew;
    if (PyType_Ready(&IterDecoder_type) < 0)
        return;
    Py_INCREF(&IterDecoder_type);
    PyModule_AddObject(
            m, "IterDecoder", (PyObject *)&IterDecoder_type);
}
