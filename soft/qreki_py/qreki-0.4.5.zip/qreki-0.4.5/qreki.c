#include "Python.h"
#include <math.h>

static const double degToRad = Py_MATH_PI / 180.0;

static double
normalize_angle(double angle) {

    angle = fmod(angle, 360.0);
    if (angle < 0.0) {
        angle += 360.0;
    }

    return angle;
}

static PyObject *
longitude_of_sun(PyObject *self, PyObject *args, PyObject *kwargs)
{
    static char *kwlist[] = {"t", NULL};
    double t, ang, th;

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "d", kwlist, &t))
        return NULL;

    /* �ۓ����̌v�Z */
    ang = normalize_angle(31557.0 * t + 161.0);
    th = .0004 * cos(degToRad * ang);
    ang = normalize_angle(29930.0 * t + 48.0);
    th += .0004 * cos(degToRad * ang);
    ang = normalize_angle(2281.0 * t + 221.0);
    th += .0005 * cos(degToRad * ang);
    ang = normalize_angle(155.0 * t + 118.0);
    th += .0005 * cos(degToRad * ang);
    ang = normalize_angle(33718.0 * t + 316.0);
    th += .0006 * cos(degToRad * ang);
    ang = normalize_angle(9038.0 * t + 64.0);
    th += .0007 * cos(degToRad * ang);
    ang = normalize_angle(3035.0 * t + 110.0);
    th += .0007 * cos(degToRad * ang);
    ang = normalize_angle(65929.0 * t + 45.0);
    th += .0007 * cos(degToRad * ang);
    ang = normalize_angle(22519.0 * t + 352.0);
    th += .0013 * cos(degToRad * ang);
    ang = normalize_angle(45038.0 * t + 254.0);
    th += .0015 * cos(degToRad * ang);
    ang = normalize_angle(445267.0 * t + 208.0);
    th += .0018 * cos(degToRad * ang);
    ang = normalize_angle(19.0 * t + 159.0);
    th += .0018 * cos(degToRad * ang);
    ang = normalize_angle(32964.0 * t + 158.0);
    th += .0020 * cos(degToRad * ang);
    ang = normalize_angle(71998.1 * t + 265.1);
    th += .0200 * cos(degToRad * ang);

    ang = normalize_angle(35999.05 * t + 267.52);
    th -= 0.0048 * t * cos(degToRad * ang);
    th += 1.9147 * cos(degToRad * ang);

    /* ��ፀ�̌v�Z */
    ang = normalize_angle(36000.7695 * t);
    ang = normalize_angle(ang + 280.4659);
    th = normalize_angle(th + ang);

    return PyFloat_FromDouble(th);
}

static PyObject *
longitude_of_moon(PyObject *self, PyObject *args, PyObject *kwargs)
{
    static char *kwlist[] = {"t", NULL};
    double t, ang, th;

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "d", kwlist, &t))
        return NULL;

    /* �ۓ����̌v�Z */
    ang = normalize_angle(2322131.0 * t + 191.0);
    th = .0003 * cos(degToRad * ang);
    ang = normalize_angle(4067.0 * t + 70.0);
    th += .0003 * cos(degToRad * ang);
    ang = normalize_angle(549197.0 * t + 220.0);
    th += .0003 * cos(degToRad * ang);
    ang = normalize_angle(1808933.0 * t + 58.0);
    th += .0003 * cos(degToRad * ang);
    ang = normalize_angle(349472.0 * t + 337.0);
    th += .0003 * cos(degToRad * ang);
    ang = normalize_angle(381404.0 * t + 354.0);
    th += .0003 * cos(degToRad * ang);
    ang = normalize_angle(958465.0 * t + 340.0);
    th += .0003 * cos(degToRad * ang);
    ang = normalize_angle(12006.0 * t + 187.0);
    th += .0004 * cos(degToRad * ang);
    ang = normalize_angle(39871.0 * t + 223.0);
    th += .0004 * cos(degToRad * ang);
    ang = normalize_angle(509131.0 * t + 242.0);
    th += .0005 * cos(degToRad * ang);
    ang = normalize_angle(1745069.0 * t + 24.0);
    th += .0005 * cos(degToRad * ang);
    ang = normalize_angle(1908795.0 * t + 90.0);
    th += .0005 * cos(degToRad * ang);
    ang = normalize_angle(2258267.0 * t + 156.0);
    th += .0006 * cos(degToRad * ang);
    ang = normalize_angle(111869.0 * t + 38.0);
    th += .0006 * cos(degToRad * ang);
    ang = normalize_angle(27864.0 * t + 127.0);
    th += .0007 * cos(degToRad * ang);
    ang = normalize_angle(485333.0 * t + 186.0);
    th += .0007 * cos(degToRad * ang);
    ang = normalize_angle(405201.0 * t + 50.0);
    th += .0007 * cos(degToRad * ang);
    ang = normalize_angle(790672.0 * t + 114.0);
    th += .0007 * cos(degToRad * ang);
    ang = normalize_angle(1403732.0 * t + 98.0);
    th += .0008 * cos(degToRad * ang);
    ang = normalize_angle(858602.0 * t + 129.0);
    th += .0009 * cos(degToRad * ang);
    ang = normalize_angle(1920802.0 * t + 186.0);
    th += .0011 * cos(degToRad * ang);
    ang = normalize_angle(1267871.0 * t + 249.0);
    th += .0012 * cos(degToRad * ang);
    ang = normalize_angle(1856938.0 * t + 152.0);
    th += .0016 * cos(degToRad * ang);
    ang = normalize_angle(401329.0 * t + 274.0);
    th += .0018 * cos(degToRad * ang);
    ang = normalize_angle(341337.0 * t + 16.0);
    th += .0021 * cos(degToRad * ang);
    ang = normalize_angle(71998.0 * t + 85.0);
    th += .0021 * cos(degToRad * ang);
    ang = normalize_angle(990397.0 * t + 357.0);
    th += .0021 * cos(degToRad * ang);
    ang = normalize_angle(818536.0 * t + 151.0);
    th += .0022 * cos(degToRad * ang);
    ang = normalize_angle(922466.0 * t + 163.0);
    th += .0023 * cos(degToRad * ang);
    ang = normalize_angle(99863.0 * t + 122.0);
    th += .0024 * cos(degToRad * ang);
    ang = normalize_angle(1379739.0 * t + 17.0);
    th += .0026 * cos(degToRad * ang);
    ang = normalize_angle(918399.0 * t + 182.0);
    th += .0027 * cos(degToRad * ang);
    ang = normalize_angle(1934.0 * t + 145.0);
    th += .0028 * cos(degToRad * ang);
    ang = normalize_angle(541062.0 * t + 259.0);
    th += .0037 * cos(degToRad * ang);
    ang = normalize_angle(1781068.0 * t + 21.0);
    th += .0038 * cos(degToRad * ang);
    ang = normalize_angle(133.0 * t + 29.0);
    th += .0040 * cos(degToRad * ang);
    ang = normalize_angle(1844932.0 * t + 56.0);
    th += .0040 * cos(degToRad * ang);
    ang = normalize_angle(1331734.0 * t + 283.0);
    th += .0040 * cos(degToRad * ang);
    ang = normalize_angle(481266.0 * t + 205.0);
    th += .0050 * cos(degToRad * ang);
    ang = normalize_angle(31932.0 * t + 107.0);
    th += .0052 * cos(degToRad * ang);
    ang = normalize_angle(926533.0 * t + 323.0);
    th += .0068 * cos(degToRad * ang);
    ang = normalize_angle(449334.0 * t + 188.0);
    th += .0079 * cos(degToRad * ang);
    ang = normalize_angle(826671.0 * t + 111.0);
    th += .0085 * cos(degToRad * ang);
    ang = normalize_angle(1431597.0 * t + 315.0);
    th += .0100 * cos(degToRad * ang);
    ang = normalize_angle(1303870.0 * t + 246.0);
    th += .0107 * cos(degToRad * ang);
    ang = normalize_angle(489205.0 * t + 142.0);
    th += .0110 * cos(degToRad * ang);
    ang = normalize_angle(1443603.0 * t + 52.0);
    th += .0125 * cos(degToRad * ang);
    ang = normalize_angle(75870.0 * t + 41.0);
    th += .0154 * cos(degToRad * ang);
    ang = normalize_angle(513197.9 * t + 222.5);
    th += .0304 * cos(degToRad * ang);
    ang = normalize_angle(445267.1 * t + 27.9);
    th += .0347 * cos(degToRad * ang);
    ang = normalize_angle(441199.8 * t + 47.4);
    th += .0409 * cos(degToRad * ang);
    ang = normalize_angle(854535.2 * t + 148.2);
    th += .0458 * cos(degToRad * ang);
    ang = normalize_angle(1367733.1 * t + 280.7);
    th += .0533 * cos(degToRad * ang);
    ang = normalize_angle(377336.3 * t + 13.2);
    th += .0571 * cos(degToRad * ang);
    ang = normalize_angle(63863.5 * t + 124.2);
    th += .0588 * cos(degToRad * ang);
    ang = normalize_angle(966404.0 * t + 276.5);
    th += .1144 * cos(degToRad * ang);
    ang = normalize_angle(35999.05 * t + 87.53);
    th += .1851 * cos(degToRad * ang);
    ang = normalize_angle(954397.74 * t + 179.93);
    th += .2136 * cos(degToRad * ang);
    ang = normalize_angle(890534.22 * t + 145.7);
    th += .6583 * cos(degToRad * ang);
    ang = normalize_angle(413335.35 * t + 10.74);
    th += 1.2740 * cos(degToRad * ang);
    ang = normalize_angle(477198.868 * t + 44.963);
    th += 6.2888 * cos(degToRad * ang);

    /* ��ፀ�̌v�Z */
    ang = normalize_angle(481267.8809 * t);
    ang = normalize_angle(ang + 218.3162);
    th = normalize_angle(th + ang);

    return PyFloat_FromDouble(th);
}

static PyMethodDef module_methods[] = {
    {"_longitude_of_sun", (PyCFunction)longitude_of_sun,
     METH_VARARGS | METH_KEYWORDS,
     "calculate longitude of sun."},
    {"_longitude_of_moon", (PyCFunction)longitude_of_moon,
     METH_VARARGS | METH_KEYWORDS,
     "calculate longitude of moon."},
    {NULL, NULL, 0, NULL} /* Sentinel */
};

PyMODINIT_FUNC
init_qreki(void) {
    PyObject* m;

    m = Py_InitModule3("_qreki", module_methods,
                       "calculate longitude of sun, moon.");
    if (m == NULL) return;
}
