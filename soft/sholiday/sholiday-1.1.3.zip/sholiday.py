# coding: utf-8

u"""祝日判定ライブラリ

//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
//_/
//_/  CopyRight(C) K.Tsunoda(AddinBox) 2001 All Rights Reserved.
//_/  ( http://www.h3.dion.ne.jp/~sakatsu/index.htm )
//_/
//_/    この祝日判定コードは『Excel:kt関数アドイン』で使用しているものです。
//_/    この関数では、２００７年施行の改正祝日法(昭和の日)までを
//_/  　サポートしています(９月の国民の休日を含む)。
//_/
//_/  (*1)このコードを引用するに当たっては、必ずこのコメントも
//_/      一緒に引用する事とします。
//_/  (*2)他サイト上で本マクロを直接引用する事は、ご遠慮願います。
//_/      【 http://www.h3.dion.ne.jp/~sakatsu/holiday_logic.htm 】
//_/      へのリンクによる紹介で対応して下さい。
//_/  (*3)[ktHolidayName]という関数名そのものは、各自の環境に
//_/      おける命名規則に沿って変更しても構いません。
//_/  
//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

追記 2007/May/26     SETOGUCHI Mitsuhiro  http://matatabi.homeip.net/

このスクリプトは JavaScript 用判定コード
http://www.h3.dion.ne.jp/~sakatsu/holiday_logic.htm#JS
を元に、Python 向けに移植したものです。

holiday_name() は、年、月、日の3つの整数の引数を取ります。
不適切な値を与えると、 ValueError が発生します。
与えた日付が日本において何らかの祝日であれば、その名前が Unicode で返ります。
祝日でない場合は None が返ります。

サンプル

import jholiday
jholiday.holiday_name(2007, 4, 28)
None
jholiday.holiday_name(2007, 4, 29)
u'\u662d\u548c\u306e\u65e5'
print jholiday.holiday_name(2007, 4, 29).encode('euc-jp')
昭和の日



追記 2009/11/15     fgshun  http://d.hatena.ne.jp/fgshun/

このスクリプトは
SETOGUCHI Mitsuhiro (http://matatabi.homeip.net/) 氏のスクリプト
(http://www.h3.dion.ne.jp/~sakatsu/holiday_logic5.htm#Python)
に、 fgshun が自分好みとなるよう、手を加えたものです。

使用上の変更点
    holiday_name_date 関数が加わりました。
    この関数は日付情報を datetime.date で受け取ります。

実装の変更点 1
    オリジナルの holiday_name 関数は
    実行直後に datetime.date インスタンスをつくっていました。
    このため日付を datetime.date で扱うコードから使うと、
        1. date を年月日の整数に直して holiday_name 関数に渡す。
        2. 関数内で datetime.date の再生成。
    という処理が行われていました。
    これを 直接 datetime.date を受け取る関数
    _holiday_name_date 関数を作ることで解消しています。

実装の変更点 2
    2001年1月1日 (CACHE_START_DAY) から 2020年1月1日 (CACHE_END_DAY)
    までの祝日を HOLIDAY_CACHE にキャッシュするようにしました。

    キャッシュする期間を変更するには、
    これらのモジュール変数を変更してください。

    _holiday_name_date 関数は HOLIDAY_CACHE キャッシュを用いません。
    キャッシュを作るためにも使われるため、キャッシュの情報に頼らずに
    休日判定を行う必要があるからです。

    holiday_name_date 関数はこのキャッシュを用います。
    この範囲内の祝日の判定速度が _holiday_name_date より速くなっています。
    代償として、キャッシュ分のメモリを必要としています。

    作者環境にて、キャシュ範囲内の日付をすべて判定することで
    速度計測を行ったところ、 _holiday_name_date の約 1.8 倍の速度でした。

実装の変更点 3
    holiday_name 関数は年月日の整数を datetime.date に変換してから、
    holiday_name_date 関数を呼ぶだけの関数となっています。

"""

import datetime

__all__ = ['holiday_name_date', 'holiday_name']

VERSION = u'1.1.3'
VERSION_INFO = (1, 1, 3)

START_DAY = datetime.date(1948, 7, 20)
MONDAY, TUESDAY, WEDNESDAY = 0, 1, 2
TIMEDELTA_D1 = datetime.timedelta(days=1)

CACHE_START_DAY = datetime.date(2001, 1, 1)
CACHE_END_DAY = datetime.date(2020, 1, 1)
HOLIDAY_CACHE = {}

def _vernal_equinox(y):
    u"""春分の日を調べる
    
    y 年の春分の日が 9 月の何日であるかを返す"""

    if y <= 1947:
        d = 0
    elif y <= 1979:
        d = int(20.8357  +  0.242194 * (y - 1980)  -  (y - 1980) // 4)
    elif y <= 2099:
        d = int(20.8431  +  0.242194 * (y - 1980)  -  (y - 1980) // 4)
    elif y <= 2150:
        d = int(21.8510  +  0.242194 * (y - 1980)  -  (y - 1980) // 4)
    else:
        d = 0

    return d

def _autumn_equinox(y):
    u"""秋分の日を調べる
    
    y 年の春分の日が 9 月の何日であるかを返す"""

    if y <= 1947:
        d = 0
    elif y <= 1979:
        d = int(23.2588  +  0.242194 * (y - 1980)  -  (y - 1980) // 4)
    elif y <= 2099:
        d = int(23.2488  +  0.242194 * (y - 1980)  -  (y - 1980) // 4)
    elif y <= 2150:
        d = int(24.2488  +  0.242194 * (y - 1980)  -  (y - 1980) // 4)
    else:
        d = 0

    return d

def _holiday_name_date(date):
    u"""祝日判定を行い祝日名を返す
    
    引数は datetime.date インスタンス。
    日付が日本における祝日でないならば None が返る。"""

    name = None
    year = date.year
    month = date.month
    day = date.day

    if date < START_DAY:
        return name

    # 1月
    if month == 1:
        if day == 1:
            name = u'元日'
        else:
            if year >= 2000:
                if (day - 1) // 7 == 1 and date.weekday() == MONDAY:
                    name = u'成人の日'
            else:
                if day == 15:
                    name = u'成人の日'
    # 2月
    elif month == 2:
        if day == 11 and year >= 1967:
            name = u'建国記念の日'
        elif year == 1989 and day == 24:
            # 1989/2/24
            name = u'昭和天皇の大喪の礼'
    # 3月
    elif month == 3:
        if day == _vernal_equinox(year):
            name = u'春分の日'
    # 4月
    elif month == 4:
        if day == 29:
            if year >= 2007:
                name = u'昭和の日'
            elif year >= 1989:
                name = u'みどりの日'
            else:
                name = u'天皇誕生日'
        elif year == 1959 and day == 10:
            # 1959/4/10
            name = u'皇太子明仁親王の結婚の儀'
    # 5月
    elif month == 5:
        if day == 3:
            name = u'憲法記念日'
        elif day == 4:
            if year >= 2007:
                name = u'みどりの日'
            elif year >= 1986 and date.weekday() != MONDAY:
                name = u'国民の休日'
        elif day == 5:
            name = u'こどもの日'
        elif day == 6:
            if year >= 2007 and date.weekday() in (TUESDAY, WEDNESDAY):
                name = u'振替休日'
    # 6月
    elif month == 6:
        if year == 1993 and day == 9:
            # 1993/6/9
            name = u'皇太子徳仁親王の結婚の儀'
    # 7月
    elif month == 7:
        if year >= 2003:
            if (day - 1) // 7 == 2 and date.weekday() == MONDAY:
                name = u'海の日'
        elif year >= 1996 and day == 20:
            name = u'海の日'
    # 9月
    elif month == 9:
        autumn_equinox = _autumn_equinox(year)
        if day == autumn_equinox:
            name = u'秋分の日'
        else:
            if year >= 2003:
                weekday = date.weekday()
                if (day - 1) // 7 == 2 and weekday == MONDAY:
                    name = u'敬老の日'
                elif weekday == TUESDAY and day == autumn_equinox - 1:
                    name = u'国民の休日'
            elif year >= 1966 and day == 15:
                name = u'敬老の日'
    # 10月
    elif month == 10:
        if year >= 2000:
            if (day - 1) // 7 == 1 and date.weekday() == MONDAY:
                name = u'体育の日'
        elif year >= 1966 and day == 10:
            name = u'体育の日'
    # 11月
    elif month == 11:
        if day == 3:
            name = u'文化の日'
        elif day == 23:
            name = u'勤労感謝の日'
        elif year == 1990 and  day == 12:
            # 1990/11/12
            name = u'即位礼正殿の儀'
    # 12月
    elif month == 12:
        if day == 23 and year >= 1989:
            name = u'天皇誕生日'

    # 振替休日
    if not name and date.weekday() == MONDAY:
        prev = date - TIMEDELTA_D1
        if _holiday_name_date(prev):
            name = u'振替休日'

    return name

def _holiday_cache():
    cache = HOLIDAY_CACHE
    date = CACHE_START_DAY
    end = CACHE_END_DAY
    while date < end:
        name = _holiday_name_date(date)
        if name:
            cache[date] = name
        date += TIMEDELTA_D1

_holiday_cache()
del _holiday_cache

def holiday_name_date(date):
    u"""祝日判定を行い祝日名を返す
    
    引数は datetime.date インスタンス。
    日付が日本における祝日でないならば None が返る。"""

    if CACHE_START_DAY <= date < CACHE_END_DAY:
        return HOLIDAY_CACHE.get(date)
    else:
        return _holiday_name_date(date)

def holiday_name(year, month, day):
    u"""祝日判定を行い祝日名を返す
    
    引数は年月日を表す 3 つの整数。
    日付が日本における祝日でないならば None が返る。"""
    return holiday_name_date(datetime.date(year, month, day))

def main():
    import optparse
    import calendar

    usage = u'%prog year month'
    version = u'%prog ' + VERSION
    parser = optparse.OptionParser(usage=usage, version=version)

    options, args = parser.parse_args()

    if len(args) != 2:
        parser.error(u'年月を指定してください')

    try:
        year = int(args[0])
        month = int(args[1])
    except (TypeError, ValueError), e:
        parser.error(u'年月を整数で指定してください')

    if not (datetime.MINYEAR <= year <= datetime.MAXYEAR):
        parser.error(u'年は %d から %d の間で指定してください' % (
            datetime.MINYEAR, datetime.MAXYEAR))

    if not (1 <= month <= 12):
        parser.error(u'月は 1 から 12 の間で指定してください')

    cal = calendar.Calendar(calendar.SUNDAY)

    for week in cal.monthdatescalendar(year, month):
        for date in week:
            if date.month != month:
                continue
            holiday = holiday_name_date(date)
            holiday = holiday if holiday else u''
            print u'%s: %s' % (date, holiday)

if __name__ == '__main__':
    main()

u"""
#//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
#//_/ CopyRight(C) K.Tsunoda(AddinBox) 2001 All Rights Reserved.
#//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
"""
