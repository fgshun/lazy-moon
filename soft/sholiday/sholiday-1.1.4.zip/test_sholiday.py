import unittest
import datetime

import sholiday
import jholiday

def range_date(start, stop, step=datetime.timedelta(1)):
    date = start
    while date < stop:
        yield date
        date += step

class HolidayNameTestCase(unittest.TestCase):
    def setUp(self):
        self.start = datetime.date(1946, 1, 1)
        self.end = datetime.date(2151, 1, 1)

    def test_h(self):
        d = sholiday.holiday_name_date
        s = sholiday.holiday_name

        for date in range_date(self.start, self.end):
            self.assertEqual(
                    d(date),
                    s(date.year, date.month, date.day))

    def test_holiday_name(self):
        s = sholiday.holiday_name
        j = jholiday.holiday_name

        for date in range_date(self.start, self.end):
            self.assertEqual(
                    s(date.year, date.month, date.day),
                    j(date.year, date.month, date.day))

if __name__ == '__main__':
    unittest.main()
