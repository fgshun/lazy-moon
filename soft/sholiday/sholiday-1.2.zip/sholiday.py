# coding: utf-8

"""祝日判定

jholiday.py
http://www.h3.dion.ne.jp/~sakatsu/holiday_logic5.htm#Python
に一定期間の先読み機構をつけるものです。
デフォルトで 2001-01-01 から 2020-01-01 までを算出しておきます。

1.1 までは移植の形をとっていましたが、
変更に追随しつづけることができなさそうなのでラップして使う形に変更しました。
オリジナルの jholiday.py も動作されるのに必要です。
"""

from __future__ import unicode_literals
from jholiday import holiday_name as _holiday_name
import datetime

__all__ = ['holiday_name_date', 'holiday_name']

VERSION = '1.2'
VERSION_INFO = (1, 2, 0)

START_DAY = datetime.date(1948, 7, 20)
MONDAY, TUESDAY, WEDNESDAY = 0, 1, 2
TIMEDELTA_D1 = datetime.timedelta(days=1)

CACHE_START_DAY = datetime.date(2001, 1, 1)
CACHE_END_DAY = datetime.date(2020, 1, 1)
HOLIDAY_CACHE = {}

def _holiday_cache():
    cache = HOLIDAY_CACHE
    date = CACHE_START_DAY
    end = CACHE_END_DAY
    while date < end:
        name = _holiday_name(date=date)
        if name:
            cache[date] = name
        date += TIMEDELTA_D1

_holiday_cache()
del _holiday_cache

def holiday_name_date(date):
    """祝日判定を行い祝日名を返す"""
    return holiday_name(date=date)

def holiday_name(year=None, month=None, day=None, date=None):
    """祝日判定を行い祝日名を返す

    引数は年月日を表す 3 つの整数。
    日付が日本における祝日でないならば None が返る。"""

    if date is None:
        date = datetime.date(year, month, day)

    if CACHE_START_DAY <= date < CACHE_END_DAY:
        return HOLIDAY_CACHE.get(date)
    else:
        return _holiday_name(date=date)

if __name__ == '__main__':
    main()
