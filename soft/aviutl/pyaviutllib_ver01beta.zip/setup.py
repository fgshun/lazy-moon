from distutils.core import setup, Extension

py_modules = ['aviutllib']

caviutl = Extension('caviutllib',
                    sources=['caviutllib.c'],
                    libraries=['User32'])

ext_modules = [caviutl]

setup (name='aviutllib',
       version='1.0',
       description='control AviUtl.',
       py_modules=py_modules,
       ext_modules=ext_modules)
