﻿#include <Python.h>
#include <Windows.h>
#include <tchar.h>

/* モジュール例外 AviUtlError */
static PyObject *AviUtlError;
/* モジュール定数 */
static PyObject *VERSION;
static PyObject *all;

/* AviUtl の hwnd を取得する
 * 取得に失敗した場合、 AviUtlError 例外をセットし NULL を返す。
 */
static HWND get_aviutl_hwnd(HWND hwnd)
{
    HWND hwndp;

    if (hwnd == NULL) {
        if ((hwnd = FindWindowW(L"AviUtl", NULL)) == NULL) {
            PyErr_SetString(AviUtlError, "Not AviUtl window.");
            return NULL;
        }
        while(hwndp = (HWND)GetWindowLong(hwnd, GWL_HWNDPARENT))
            hwnd = hwndp;
    }
    else {
        hwndp = hwnd;
        hwnd = NULL;
        do {
            hwnd = FindWindowExW(NULL, hwnd, L"AviUtl", NULL);
            if (hwnd == NULL) {
                PyErr_SetString(AviUtlError, "Not AviUtl window.");
                return NULL;
            }
        } while(hwnd != hwndp);
        if ((HWND)GetWindowLong(hwnd, GWL_HWNDPARENT) != NULL) {
            PyErr_SetString(AviUtlError, "Not AviUtl root window.");
            return NULL;
        }
    }

    return hwnd;
}

/* AviUtl の ダイアログの hwnd を取得する
 * 取得に失敗した場合、 AviUtlError 例外をセットし NULL を返す。
 */
static HWND get_aviutl_dlghwnd(HWND hwnd)
{
    HWND hwndd, hwndp;
    int i;

    Sleep(500);
    for(i = 0; ; i++){
        hwndd = FindWindowExW(NULL, NULL, L"#32770", NULL);
        hwndp = (HWND)GetWindowLong(hwndd, GWL_HWNDPARENT);
        while(hwndd != 0 && hwndp != hwnd){
            hwndd = FindWindowExW(NULL, hwndd, L"#32770", NULL);
            hwndp = (HWND)GetWindowLong(hwndd, GWL_HWNDPARENT);
        }
        if (hwndd != 0 && hwndp == hwnd) break;
        if (i >= 20){
            PyErr_SetString(
                    AviUtlError, "Dialog of output-plgin didnt appear.");
            return NULL;
        }
        Sleep(500);
    }
    Sleep(2000);

    return hwndd;
}

/* なにかダイアログを開いて「開く」ボタンを押す */
static PyObject*
dlg_open(const wchar_t *filename, HWND hwnd, WPARAM w_param, LPARAM l_param)
{
    HWND hwnds, hwndb, hwndcbx, hwndcb, hwnde;

    hwnd = get_aviutl_hwnd(hwnd);
    if (hwnd == NULL) return NULL;

    PostMessageW(hwnd, WM_COMMAND, w_param, l_param);

    hwnds = get_aviutl_dlghwnd(hwnd);
    if (hwnds == NULL) return NULL;

    hwndb = FindWindowExW(hwnds, NULL, L"Button", L"開く(&O)");
    hwndcbx = FindWindowExW(hwnds, NULL, L"ComboBoxEx32", NULL);
    hwndcb = FindWindowExW(hwndcbx, NULL, L"ComboBox", NULL);
    hwnde = FindWindowExW(hwndcb, NULL, L"Edit", NULL);

    SendMessageW(hwnde, WM_SETTEXT, 0, (LPARAM)filename);
    SendMessageW(hwndb, WM_LBUTTONDOWN, 0, 0);
    SendMessageW(hwndb, WM_LBUTTONUP, 0, 0);

    Py_RETURN_NONE;
}

/* なにかダイアログを開いて「保存」ボタンを押す */
static PyObject*
dlg_save(wchar_t *filename, HWND hwnd, WPARAM w_param, LPARAM l_param, int out)
{
    HWND hwnds, hwndb, hwndcbx, hwndcb, hwnde;

    hwnd = get_aviutl_hwnd(hwnd);
    if (hwnd == NULL) return NULL;

    PostMessageW(hwnd, WM_COMMAND, w_param, l_param);

    hwnds = get_aviutl_dlghwnd(hwnd);
    if (hwnds == NULL) return NULL;

    if (out)
        hwndb = FindWindowExW(hwnds, NULL, L"Button", L"保存(&S)");
    else {
        hwndb = FindWindowExW(hwnds, NULL, L"#32770", NULL);
        hwndb = FindWindowExW(hwndb, NULL, L"Button", L"バッチ登録");
    }
    hwndcbx = FindWindowExW(hwnds, NULL, L"ComboBoxEx32", NULL);
    hwndcb = FindWindowExW(hwndcbx, NULL, L"ComboBox", NULL);
    hwnde = FindWindowExW(hwndcb, NULL, L"Edit", NULL);

    SendMessageW(hwnde, WM_SETTEXT, 0, (LPARAM)filename);
    SendMessageW(hwndb, WM_LBUTTONDOWN, 0, 0);
    SendMessageW(hwndb, WM_LBUTTONUP, 0, 0);

    Py_RETURN_NONE;
}

/* AVI 出力する */
static PyObject *
caviutl_aviout(PyObject *self, PyObject *args, PyObject *kwargs)
{
    Py_UNICODE *filename;
    HWND hwnd = NULL;
    PyObject *ret;

    static char *kwlist[] = {"filename", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "u|i", kwlist, &filename, &hwnd))
        return NULL;

    ret = dlg_save(filename, hwnd, 1003, 0, 1);

    return ret;
}

/* WAV 出力する */
static PyObject *
caviutl_wavout(PyObject *self, PyObject *args, PyObject *kwargs)
{
    Py_UNICODE *filename;
    HWND hwnd = NULL;
    PyObject *ret;

    static char *kwlist[] = {"filename", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "u|i", kwlist, &filename, &hwnd))
        return NULL;

    ret = dlg_save(filename, hwnd, 1062, 0, 1);

    return ret;
}

/* ファイルを閉じる */
static PyObject *
caviutl_close(PyObject *self, PyObject *args, PyObject *kwargs)
{
    HWND hwnd = NULL;

    static char *kwlist[] = {"hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "|i", kwlist, &hwnd))
        return NULL;

    hwnd = get_aviutl_hwnd(hwnd);
    if (hwnd == NULL) return NULL;

    PostMessageW(hwnd, WM_COMMAND, 5157, 0);

    Py_RETURN_NONE;
}

/* AviUtl を終了する */
static PyObject *
caviutl_exit(PyObject *self, PyObject *args, PyObject *kwargs)
{
    HWND hwnd = NULL;

    static char *kwlist[] = {"hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "|i", kwlist, &hwnd))
        return NULL;

    hwnd = get_aviutl_hwnd(hwnd);
    if (hwnd == NULL) return NULL;

    PostMessageW(hwnd, WM_COMMAND, 1002, 0);

    Py_RETURN_NONE;
}

/* caviutl_exe 用コールバック関数
 */
static HWND g_hwnd = NULL;

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
    DWORD dwProcessId;
    wchar_t buf[8];

    GetWindowThreadProcessId(hwnd, &dwProcessId);
    if (dwProcessId != (DWORD)lParam) return TRUE;

    GetWindowTextW(hwnd, buf, 7);
    if (wcscmp(buf, L"AviUtl")) return TRUE;

    g_hwnd = hwnd;
    return FALSE;
}

/* AviUtl を起動し、ウィンドウ番号を返す
 */
static PyObject *
caviutl_exec_(PyObject *self, PyObject *args, PyObject *kwargs)
{
    Py_UNICODE *aviutl_path;
    HWND hwnd;
    PROCESS_INFORMATION pi;
    STARTUPINFOW si;

    static char *kwlist[] = {"aviutl_path", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "u", kwlist, &aviutl_path))
        return NULL;

    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);

    if (!CreateProcessW(NULL, (LPWSTR)aviutl_path, NULL, NULL, FALSE,
        NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi)) {
        PyErr_SetString(AviUtlError, "can not execute AviUtl.");
        return NULL;
    }
    while (EnumWindows(EnumWindowsProc, pi.dwProcessId))
        Sleep(100);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    hwnd = g_hwnd;
    g_hwnd = NULL;

    return Py_BuildValue("i", hwnd);
}

/* AviUtl の ウィンドウ番号を得る
 */
static PyObject *
caviutl_findwnd(PyObject *self, PyObject *args, PyObject *kwargs)
{
    HWND hwnd;

    static char *kwlist[] = {NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "", kwlist))
        return NULL;

    hwnd = get_aviutl_hwnd(NULL);
    if (hwnd == NULL) return NULL;

    return Py_BuildValue("i", hwnd);
}

/* ファイルを開く */
static PyObject *
caviutl_open(PyObject *self, PyObject *args, PyObject *kwargs)
{
    Py_UNICODE *filename;
    HWND hwnd = NULL;

    static char *kwlist[] = {"filename", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "u|i", kwlist, &filename, &hwnd))
        return NULL;

    return dlg_open(filename, hwnd, 5097, 0);
}

/* ファイルを追加読み込みする */
static PyObject *
caviutl_openadd(PyObject *self, PyObject *args, PyObject *kwargs)
{
    Py_UNICODE *filename;
    HWND hwnd = NULL;

    static char *kwlist[] = {"filename", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "u|i", kwlist, &filename, &hwnd))
        return NULL;

    return dlg_open(filename, hwnd, 5100, 0);
}

/* ファイルを音声読み込みする */
static PyObject *
caviutl_audioadd(PyObject *self, PyObject *args, PyObject *kwargs)
{
    Py_UNICODE *filename;
    HWND hwnd = NULL;

    static char *kwlist[] = {"filename", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "u|i", kwlist, &filename, &hwnd))
        return NULL;

    return dlg_open(filename, hwnd, 5168, 0);
}

/* プロジェクトファイルを開く */
static PyObject *
caviutl_openprj(PyObject *self, PyObject *args, PyObject *kwargs)
{
    Py_UNICODE *filename;
    HWND hwnd = NULL;

    static char *kwlist[] = {"filename", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "u|i", kwlist, &filename, &hwnd))
        return NULL;

    return dlg_open(filename, hwnd, 5118, 0);
}

/* 出力プラグインを指定してバッチ登録する */
static PyObject *
caviutl_plugbatch(PyObject *self, PyObject *args, PyObject *kwargs)
{
    int plugin_num;
    Py_UNICODE *filename;
    HWND hwnd = NULL;
    PyObject *ret;

    static char *kwlist[] = {"plugin_num", "filename", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "iu|i", kwlist, &plugin_num, &filename, &hwnd))
        return NULL;

    ret = dlg_save(filename, hwnd, 5296 + plugin_num, 0, 0);

    return ret;
}

/* 出力プラグインを指定して出力する */
static PyObject *
caviutl_plugout(PyObject *self, PyObject *args, PyObject *kwargs)
{
    int plugin_num;
    Py_UNICODE *filename;
    HWND hwnd = NULL;
    PyObject *ret;

    static char *kwlist[] = {"plugin_num", "filename", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "iu|i", kwlist, &plugin_num, &filename, &hwnd))
        return NULL;

    ret = dlg_save(filename, hwnd, 5296 + plugin_num, 0, 1);

    return ret;
}

/* プロジェクトを保存する */
static PyObject *
caviutl_saveprj(PyObject *self, PyObject *args, PyObject *kwargs)
{
    Py_UNICODE *filename;
    HWND hwnd = NULL;
    PyObject *ret;

    static char *kwlist[] = {"filename", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "u|i", kwlist, &filename, &hwnd))
        return NULL;

    ret = dlg_save(filename, hwnd, 1023, 0, 1);

    return ret;
}
/* プロファイルを選択する */
static PyObject *
caviutl_setprof(PyObject *self, PyObject *args, PyObject *kwargs)
{
    int prof_num;
    HWND hwnd = NULL;

    static char *kwlist[] = {"prof_num", "hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(
                args, kwargs, "i|i", kwlist, &prof_num, &hwnd))
        return NULL;

    hwnd = get_aviutl_hwnd(hwnd);
    if (hwnd == NULL) return NULL;

    PostMessageW(hwnd, WM_COMMAND, 8006 + prof_num, 0);

    Py_RETURN_NONE;
}

/* バージョン情報ダイアログを閉じる（出力を再開する） */
static PyObject *
caviutl_verclose(PyObject *self, PyObject *args, PyObject *kwargs)
{
    HWND hwnd = NULL;
    HWND hwndp, hwnds, hwndb;

    static char *kwlist[] = {"hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "|i", kwlist, &hwnd))
        return NULL;

    hwnd = get_aviutl_hwnd(hwnd);
    if (hwnd == NULL) return NULL;

    hwnds = FindWindowExW(NULL, NULL, L"#32770", L"バージョン情報");
    hwndp = (HWND)GetWindowLongW(hwnds, GWL_HWNDPARENT);
    while(hwnds != 0 && hwndp != hwnd){
        hwnds = FindWindowExW(NULL, hwnds, L"#32770", L"バージョン情報");
        hwndp = (HWND)GetWindowLong(hwnds, GWL_HWNDPARENT);
    }
    if(hwnds == 0 || hwndp != hwnd) {
        PyErr_SetString(AviUtlError, "Dialog not found.");
        return NULL;
    }

    hwndb = FindWindowExW(hwnds, NULL, L"Button", L"OK");
    if(hwndb == NULL) {
        PyErr_SetString(AviUtlError, "Unexpected dialog.");
        return NULL;
    }

    SendMessageW(hwndb, WM_LBUTTONDOWN, 0, 0);
    SendMessageW(hwndb, WM_LBUTTONDOWN, 0, 0);
    SendMessageW(hwndb, WM_LBUTTONUP, 0, 0);

    Py_RETURN_NONE;
}

/* バージョン情報ダイアログを開く（出力を中断する） */
static PyObject *
caviutl_veropen(PyObject *self, PyObject *args, PyObject *kwargs)
{
    HWND hwnd = NULL;

    static char *kwlist[] = {"hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "|i", kwlist, &hwnd))
        return NULL;

    hwnd = get_aviutl_hwnd(hwnd);
    if (hwnd == NULL) return NULL;

    PostMessageW(hwnd, WM_COMMAND, 100, 0);

    Py_RETURN_NONE;
}

/* AviUtl の出力が終了するまで待つ */
static PyObject *
caviutl_wait(PyObject *self, PyObject *args, PyObject *kwargs)
{
    HWND hwnd = NULL;
    HANDLE hprc;
    wchar_t buf[256];
    DWORD old_process_class;
    int i;

    static char *kwlist[] = {"hwnd", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "|i", kwlist, &hwnd))
        return NULL;

    hwnd = get_aviutl_hwnd(hwnd);
    if (hwnd == NULL) return NULL;

    hprc = GetCurrentProcess();
    old_process_class = GetPriorityClass(hprc);
    SetPriorityClass(hprc, IDLE_PRIORITY_CLASS);

    for(i = 0; i < 7; i++){
        GetWindowTextW(hwnd, buf, 256);
        if(wcsncmp(buf, L"出力中", 3) == 0 || wcsncmp(buf, L"検索中", 3) == 0){
            Sleep(5000);
            i = -1;
        }else
            Sleep(500);
    }

    SetPriorityClass(hprc, old_process_class);

    Py_RETURN_NONE;
}

static PyMethodDef module_methods[] = {
    {"aviout", (PyCFunction)caviutl_aviout,
     METH_VARARGS | METH_KEYWORDS,
     "output AVI file."},
    {"wavout", (PyCFunction)caviutl_wavout,
     METH_VARARGS | METH_KEYWORDS,
     "output WAV file."},
    {"close", (PyCFunction)caviutl_close,
     METH_VARARGS | METH_KEYWORDS,
     "close file."},
    {"exit", (PyCFunction)caviutl_exit,
     METH_VARARGS | METH_KEYWORDS,
     "exit AviUtl."},
    {"exec_", (PyCFunction)caviutl_exec_,
     METH_VARARGS | METH_KEYWORDS,
     "execute AviUtl."},
    {"findwnd", (PyCFunction)caviutl_findwnd,
     METH_VARARGS | METH_KEYWORDS,
     "get AviUtl window handle."},
    {"open", (PyCFunction)caviutl_open,
     METH_VARARGS | METH_KEYWORDS,
     "open file."},
    {"openadd", (PyCFunction)caviutl_openadd,
     METH_VARARGS | METH_KEYWORDS,
     "add file."},
    {"audioadd", (PyCFunction)caviutl_audioadd,
     METH_VARARGS | METH_KEYWORDS,
     "open audio file."},
    {"openprj", (PyCFunction)caviutl_openprj,
     METH_VARARGS | METH_KEYWORDS,
     "open project file."},
    {"plugbatch", (PyCFunction)caviutl_plugbatch,
     METH_VARARGS | METH_KEYWORDS,
     "output file with plugin."},
    {"plugout", (PyCFunction)caviutl_plugout,
     METH_VARARGS | METH_KEYWORDS,
     "output file with plugin."},
    {"saveprj", (PyCFunction)caviutl_saveprj,
     METH_VARARGS | METH_KEYWORDS,
     "save project file."},
    {"setprof", (PyCFunction)caviutl_setprof,
     METH_VARARGS | METH_KEYWORDS,
     "select profile."},
    {"verclose", (PyCFunction)caviutl_verclose,
     METH_VARARGS | METH_KEYWORDS,
     "close version dialog."},
    {"veropen", (PyCFunction)caviutl_veropen,
     METH_VARARGS | METH_KEYWORDS,
     "open version dialog."},
    {"wait", (PyCFunction)caviutl_wait,
     METH_VARARGS | METH_KEYWORDS,
     "wait end of output."},
    {NULL, NULL, 0, NULL} /* Sentinel */
};

PyMODINIT_FUNC
initcaviutllib(void)
{
    PyObject* m;

    m = Py_InitModule3("caviutllib", module_methods,
                       "control AviUtl.");
    if (m == NULL)
      return;

    AviUtlError = PyErr_NewException(
            "caviutl.AviUtlError", PyExc_StandardError, NULL);
    Py_INCREF(AviUtlError);
    PyModule_AddObject(m, "AviUtlError", AviUtlError);

    VERSION = Py_BuildValue("u", L"0.1 beta");
    Py_INCREF(VERSION);
    PyModule_AddObject(m, "__version__", VERSION);

    all = Py_BuildValue("[ssssssssssssssssss]",
        "AviUtlError",
        "aviout", "wavout", "close", "exec_", "exit", "findwnd",
        "open", "openadd", "audioadd", "openprj", "plugbatch",
        "plugout", "saveprj", "setprof", "verclose", "veropen", "wait");
    Py_INCREF(all);
    PyModule_AddObject(m, "__all__", all);
}
