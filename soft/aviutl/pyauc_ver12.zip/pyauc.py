# coding: utf-8
u"""AviUtl を Python から操作する

作成: fgshun
『銀月の符号』 http://d.hatena.ne.jp/fgshun/

AviUtl Control ver1.4 を使用する。
http://www.geocities.jp/aji_0/
"""

import subprocess

__version__ = u'1.2'
__auc_version__ = u'1.4'

def _call_auc(exe, window=None, *args):
    u"""auc_*.exe を呼ぶショートカット関数"""
    command = [exe]
    command.extend(map(str, args))
    if window is not None:
        command.insert(1, (str(window)))
    subprocess.check_call(command)

def aviout(filename, window=None):
    u"""AVI 出力する
    
    出力の終了を待たずに返る。
    終了するまで待つには、この後に wait を呼べばよい。

    出力ファイルと同名のファイルがすでに存在し、
    上書き確認のダイアログが出てしまうと、止まってしまうので注意。
    「システムの設定」の「ファイル選択ダイアログで上書き確認をしない」
    を有効にしておくと回避できる。"""
    _call_auc('auc_aviout.exe', window, filename)

def close(window=None):
    u"""ファイルを閉じる"""
    _call_auc('auc_close.exe', window)

def exec_(aviutl_path):
    u"""AviUtl を起動し、ウィンドウ番号を返す

    auc_exec.exe はウィンドウ番号を標準出力にも出力する。"""
    return subprocess.call(['auc_exec.exe', str(aviutl_path)])

def exit(window=None):
    u"""AviUtl を終了する"""
    _call_auc('auc_exit.exe', window)

def findwnd(caption=None):
    u"""AviUtl のウィンドウ番号を得る
    
    複数開いている場合でも、どれか一つの番号しか得られない。"""
    command = ['auc_findwnd.exe']
    if caption is not None:
        command.append(str(caption))
    return subprocess.call(command)

def open(filename, window=None):
    u"""ファイルを開く"""
    _call_auc('auc_open.exe', window, filename)

def openadd(filename, window=None):
    u"""ファイルを追加読み込みする"""
    _call_auc('auc_openadd.exe', window, filename)

def audioadd(filename, window=None):
    u"""ファイルを音声読み込みする"""
    _call_auc('auc_audioadd.exe', window, filename)

def openprj(filename, window=None):
    u"""プロジェクトファイルを開く"""
    _call_auc('auc_openprj.exe', window, filename)

def plugbatch(plugin_num, filename, window=None):
    u"""出力プラグインを指定してバッチ登録する
    
    plugin_num で出力プラグインを指定する。
    メニューで一番上の出力プラグインが 0 で、以下 1, 2 ..."""
    _call_auc('auc_plugbatch.exe', window, plugin_num, filename)

def plugout(plugin_num, filename, window=None):
    u"""出力プラグインを指定して出力する
    
    plugin_num で出力プラグインを指定する。
    メニューで一番上の出力プラグインが 0 で、以下 1, 2 ..."""
    _call_auc('auc_plugout.exe', window, plugin_num, filename)

def saveprj(filename, window=None):
    u"""プロジェクトを保存する"""
    _call_auc('auc_saveprj.exe', window, filename)

def setprof(prof_num, window=None):
    u"""プロファイルを選択する
    
    メニューで一番上のプロファイルの番号が 0 で、以下 1, 2..."""
    _call_auc('auc_setprof.exe', window, prof_num)

def verclose(window=None):
    u"""バージョン情報ダイアログを閉じる（出力を再開する）
    
    ダイアログが開いていない時はエラーとなる。"""
    # TODO: ダイアログが開いていない時の exe の戻り値は -1
    #       チェックは呼び出し側に行わせるように変更するかどうか考える。
    _call_auc('auc_verclose.exe', window)

def veropen(window=None):
    u"""バージョン情報ダイアログを開く（出力を中断する）
    
    ダイアログがすでに開いていてもエラーとならないうえに
    ダイアログが2つ以上あるという状態になるので注意。"""
    _call_auc('auc_veropen.exe', window)

def wait(window=None):
    u"""AviUtl の出力が終了するまで待つ"""
    _call_auc('auc_wait.exe', window)

def wavout(filename, window=None):
    u"""WAV 出力する
    
    出力の終了を待たずに返る。
    終了するまで待つには、この後に wait を呼べばよい。

    出力ファイルと同名のファイルがすでに存在し、
    上書き確認のダイアログが出てしまうと、止まってしまうので注意。
    「システムの設定」の「ファイル選択ダイアログで上書き確認をしない」
    を有効にしておくと回避できる。"""
    _call_auc('auc_wait.exe', window, filename)
