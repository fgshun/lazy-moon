# coding: utf-8
u"""AviUtl を Python から操作する

作成: fgshun
『銀月の符号』 http://d.hatena.ne.jp/fgshun/

AviUtl Control ver1.4 のソースをもとに作成しました。
ありがとうございます。
http://www.geocities.jp/aji_0/
"""

import itertools
import time
from ctypes import windll, WINFUNCTYPE, GetLastError, WinError
from ctypes import Structure, cast, POINTER, byref, sizeof
from ctypes import c_int, c_wchar_p, c_void_p, create_unicode_buffer
from ctypes.wintypes import BOOL, BYTE, UINT, LONG
from ctypes.wintypes import LPVOID, LPCWSTR, LPWSTR, HWND
from ctypes.wintypes import WPARAM, LPARAM, WORD, DWORD, HANDLE

__all__ = [
        'VERSION', 'AviUtlError',
        'aviout', 'wavout', 'close', 'exec_', 'exit', 'findwnd',
        'open', 'openadd', 'audioadd', 'openproj', 'plugbatch', 'plugout',
        'saveprj', 'setprof', 'verclose', 'veropen', 'wait']

VERSION = u'0.1 alpha'

class AviUtlError(StandardError):
    pass

kernel32 = windll.LoadLibrary('kernel32.dll')
user32 = windll.LoadLibrary('user32.dll')

WM_COMMAND = 0x111
WM_SETTEXT = 0x0c
WM_LBUTTONDOWN = 0x201
WM_LBUTTONUP = 0x202
GWL_HWNDPARENT = -0x08
NORMAL_PRIORITY_CLASS = 0x20
IDLE_PRIORITY_CLASS = 0x40
HIGH_PRIORITY_CLASS = 0x80
REALTIME_PRIORITY_CLASS = 0x100

LPCTSTR = LPCWSTR
LPTSTR = LPWSTR
LPBYTE = POINTER(BYTE)
LPDWORD = POINTER(DWORD)

class STARTUPINFO(Structure):
    _fields_ = [
            ('cb', DWORD),
            ('lpReserved', LPTSTR),
            ('lpDesktop', LPTSTR),
            ('lpTitle', LPTSTR),
            ('dwX', DWORD),
            ('dwY', DWORD),
            ('dwXSize', DWORD),
            ('dwYSize', DWORD),
            ('dwXCountChars', DWORD),
            ('dwYCountChars', DWORD),
            ('dwFillAttribure', DWORD),
            ('dwFlags', DWORD),
            ('wShowWindow', WORD),
            ('cbReserved2', WORD),
            ('lpReserved2', LPBYTE),
            ('hStdInput', HANDLE),
            ('hStdOutput', HANDLE),
            ('hStdError', HANDLE)]

LPSTARTUPINFO = POINTER(STARTUPINFO)

class PROCESS_INFOMATION(Structure):
    _fields_ = [
            ('hProcess', HANDLE),
            ('hThread', HANDLE),
            ('dwProcessId', DWORD),
            ('dwThreadId', DWORD)]

LPPROCESS_INFOMATION = POINTER(PROCESS_INFOMATION)

class SECURITY_ATTRIBUTES(Structure):
    _fields_ = [
            ('nLength', DWORD),
            ('lpSecurityDescriptor', LPVOID),
            ('bInheritHandle', BOOL)]

LPSECURITY_ATTRIBUTES = POINTER(SECURITY_ATTRIBUTES)

def _errcheck_false(result, func, args):
    if not result:
        raise WinError()
    return args

def _errcheck_ex(result, func, args):
    if not result:
        errcode = GetLastError()
        if errcode:
            raise WinError(errcode)
    return args

FindWindow = WINFUNCTYPE(HWND, LPCTSTR, LPCTSTR)(
        ('FindWindowW', user32),
        ((1, 'lpClassName'), (1, 'lpWindowName'))
        )
FindWindow.errcheck = _errcheck_false

FindWindowEx = WINFUNCTYPE(HWND, HWND, HWND, LPCTSTR, LPCTSTR)(
        ('FindWindowExW', user32),
        ( (1, 'hwndParent'),
          (1, 'hwndChildAfter'),
          (1, 'lpClassName'),
          (1, 'lpWindowName'),
          )
        )
FindWindowEx.errcheck = _errcheck_false

PostMessage = WINFUNCTYPE(BOOL, HWND, UINT, WPARAM, LPARAM)(
        ('PostMessageW', user32),
        ((1, 'hWnd'), (1, 'Msg'), (1, 'wParam'), (1, 'lParam'))
        )
PostMessage.errcheck = _errcheck_ex

SendMessage = WINFUNCTYPE(BOOL, HWND, UINT, WPARAM, LPARAM)(
        ('SendMessageW', user32),
        ((1, 'hWnd'), (1, 'Msg'), (1, 'wParam'), (1, 'lParam'))
        )

GetWindowLong = WINFUNCTYPE(LONG, HWND, c_int)(
        ('GetWindowLongW', user32),
        ((1, 'hWnd'), (1, 'nIndex'))
        )
GetWindowLong.errcheck = _errcheck_false

EnumWindows = WINFUNCTYPE(BOOL, HWND, LPARAM)(
        ('EnumWindows', user32),
        ((1, 'lpEnumFunc'), (1, 'lParam'))
        )
EnumWindows.errcheck = _errcheck_ex

GetWindowThreadProcessId = WINFUNCTYPE(DWORD, HWND, LPDWORD)(
        ('GetWindowThreadProcessId', user32),
        ((1, 'hWnd'), (1, 'lpdwProcessId'))
        )

GetWindowText = WINFUNCTYPE(c_int, HWND, LPTSTR, c_int)(
        ('GetWindowTextW', user32),
        ((1, 'hWnd'), (1, 'lpString'), (1, 'nMaxCount'))
        )
GetWindowText.errcheck = _errcheck_ex

CreateProcess = WINFUNCTYPE(
        BOOL, LPCTSTR, LPTSTR, LPSECURITY_ATTRIBUTES,
        LPSECURITY_ATTRIBUTES, BOOL, DWORD, LPVOID, LPCTSTR,
        LPSTARTUPINFO, LPPROCESS_INFOMATION)(
        ('CreateProcessW', kernel32),
        ((1, 'lpApplicationName'), (1, 'lpCommandLine'),
         (1, 'lpProcessAttributes'), (1, 'lpThreadAttributes'),
         (1, 'bInheritHandles'), (1, 'dwCreationFlags'),
         (1, 'lpEnvironment'), (1, 'lpCurrentDirectory'),
         (1, 'lpStartupInfo'), (1, 'lpProcessInformation'))
        )
CreateProcess.errcheck = _errcheck_ex

CloseHandle = WINFUNCTYPE(BOOL, HANDLE)(
        ('CloseHandle', kernel32),
        ((1, 'hObject'),)
        )
CloseHandle.errcheck = _errcheck_ex

GetPriorityClass = WINFUNCTYPE(DWORD, HANDLE)(
        ('GetPriorityClass', kernel32), ((1, 'hProcess'),))
GetPriorityClass.errcheck = _errcheck_ex

SetPriorityClass = WINFUNCTYPE(BOOL, HANDLE, DWORD)(
        ('SetPriorityClass', kernel32),
        ((1, 'hProcess'), (1, 'dwPriorityClass'))
        )
SetPriorityClass.errcheck = _errcheck_ex

GetCurrentProcess = WINFUNCTYPE(HANDLE)(
        ('GetCurrentProcess', kernel32), ())
GetCurrentProcess.errcheck = _errcheck_ex

def get_aviutl_hwnd(child_hwnd=None, caption=None):
    u"""AviUtl のウィンドウ番号を得る"""
    hwnd = None
    hwndp = None
    if child_hwnd is None:
        try:
            hwnd = FindWindow(u'AviUtl', caption)
        except WindowsError:
            raise AviUtlError(u'Not Aviutl window')
        try:
            while True:
                hwnd = GetWindowLong(hwnd, GWL_HWNDPARENT)
        except WindowsError:
            pass
    else:
        try:
            while hwnd != child_hwnd:
                hwnd = FindWindowEx(None, hwnd, u'AviUtl', caption)
        except WindowsError:
            raise AviUtlError(u'Not Aviutl window')
        try:
            GetWindowLong(hwnd, GWL_HWNDPARENT)
            raise AviUtlError(u'Not Aviutl root window')
        except WindowsError:
            pass
    return hwnd

def get_aviutl_dlghwnd(hwnd):
    u"""AviUtl のダイアログのウィンドウ番号を得る"""
    hwndd = None
    hwndp = None
    for i in itertools.count():
        try:
            hwndd = FindWindowEx(None, None, u'#32770', None)
            hwndp = GetWindowLong(hwndd, GWL_HWNDPARENT)
            while hwndp != hwnd:
                hwndd = FindWindowEx(None, hwndd, u'#32770', None)
                hwndp = GetWindowLong(hwndd, GWL_HWNDPARENT)
        except WindowsError:
            pass
        if hwndp == hwnd:
            break
        if i >= 20:
            raise AviUtlError(u'Not Aviutl window')
        time.sleep(0.5)
    time.sleep(2)
    return hwndd

def _open(filename, hwnd, w_param, l_param):
    u"""なにかダイアログを開いて「開く」ボタンを押すコマンドの雛形"""
    hwnd = get_aviutl_hwnd(hwnd)
    PostMessage(hwnd, WM_COMMAND, w_param, l_param)

    hwnds = get_aviutl_dlghwnd(hwnd)
    hwndb = FindWindowEx(hwnds, None, u'Button', u'開く(&O)')
    hwndcbx = FindWindowEx(hwnds, None, u'ComboBoxEx32', None)
    hwndcb = FindWindowEx(hwndcbx, None, u'ComboBox', None)
    hwnde = FindWindowEx(hwndcb, None, u'Edit', None)

    c_filename = c_wchar_p(filename)
    SendMessage(hwnde, WM_SETTEXT, 0, cast(c_filename, c_void_p).value)
    SendMessage(hwndb, WM_LBUTTONDOWN, 0, 0)
    SendMessage(hwndb, WM_LBUTTONUP, 0, 0)

def _save(filename, hwnd, w_param, l_param, out):
    u"""なにかダイアログを開いて「保存」ボタンを押すコマンドの雛形
    
    out が偽値ならば「保存」の代わりに「バッチ登録」を押す。"""
    hwnd = get_aviutl_hwnd(hwnd)
    PostMessage(hwnd, WM_COMMAND, w_param, l_param)

    hwnds = get_aviutl_dlghwnd(hwnd)
    if out:
        hwndb = FindWindowEx(hwnds, None, u'Button', u'保存(&S)')
    else:
        hwndb = FindWindowEx(hwnds, None, u'#32770', None)
        hwndb = FindWindowEx(hwndb, None, u'Button', u'バッチ登録')
    hwndcbx = FindWindowEx(hwnds, None, u'ComboBoxEx32', None)
    hwndcb = FindWindowEx(hwndcbx, None, u'ComboBox', None)
    hwnde = FindWindowEx(hwndcb, None, u'Edit', None)

    c_filename = c_wchar_p(filename)
    SendMessage(hwnde, WM_SETTEXT, 0, cast(c_filename, c_void_p).value)
    SendMessage(hwndb, WM_LBUTTONDOWN, 0, 0)
    SendMessage(hwndb, WM_LBUTTONUP, 0, 0)

def aviout(filename, hwnd=None):
    u"""AVI 出力する"""
    _save(filename, hwnd, 1003, 0, True)

def wavout(filename, hwnd=None):
    u"""WAV 出力する"""
    _save(filename, hwnd, 1062, 0, True)

def close(hwnd=None):
    u"""ファイルを閉じる"""
    hwnd = get_aviutl_hwnd(hwnd)
    PostMessage(hwnd, WM_COMMAND, 5157, 0)

class _Proc(object):
    u"""exec_ 用 EnumWindowsProc"""
    def __init__(self):
        self.hwnd = 0

    def __call__(self, hwnd, lParam):
        dwProcessId = DWORD()
        buf = create_unicode_buffer(8)

        GetWindowThreadProcessId(hwnd, byref(dwProcessId))
        if dwProcessId.value != lParam:
            return True

        GetWindowText(hwnd, buf, 7)
        if buf.value != u"AviUtl":
            return True

        self.hwnd = hwnd
        return False

    def reset(self):
        self.hwnd = 0

_proc = _Proc()
EnumWindowsProc = WINFUNCTYPE(BOOL, HWND, LPARAM)(_proc)

def exec_(aviutl_path):
    u"""AviUtl を起動し、ウィンドウ番号を返す"""
    pi = PROCESS_INFOMATION()
    si = STARTUPINFO()
    si.cb = sizeof(si)

    try:
        CreateProcess(
                None, aviutl_path, None, None, False,
                NORMAL_PRIORITY_CLASS, None, None, byref(si), byref(pi))
    except WindowsError:
        return 0

    hwnd = 0
    try:
        ret = EnumWindows(EnumWindowsProc, pi.dwProcessId)
        while ret:
            time.sleep(0.1)
            ret = EnumWindows(EnumWindowsProc, pi.dwProcessId)
    finally:
        hwnd = _proc.hwnd
        _proc.reset()

    CloseHandle(pi.hProcess)
    CloseHandle(pi.hThread)
    return hwnd

def exit(hwnd=None):
    u"""AviUtl を終了する"""
    hwnd = get_aviutl_hwnd(hwnd)
    PostMessage(hwnd, WM_COMMAND, 1002, 0)

findwnd = get_aviutl_hwnd

def open(filename, hwnd=None):
    u"""ファイルを開く"""
    _open(filename, hwnd, 5097, 0)

def openadd(filename, hwnd=None):
    u"""ファイルを追加読み込みする"""
    _open(filename, hwnd, 5100, 0)

def audioadd(filename, hwnd=None):
    u"""ファイルを音声読み込みする"""
    _open(filename, hwnd, 5168, 0)

def openproj(filename, hwnd=None):
    u"""プロジェクトファイルを開く"""
    _open(filename, hwnd, 5118, 0)

def plugbatch(plugin_num, filename, hwnd=None):
    u"""出力プラグインを指定してバッチ登録する"""
    _save(filename, hwnd, 5296 + plugin_num, 0, False)

def plugout(plugin_num, filename, hwnd=None):
    u"""出力プラグインを指定して出力する"""
    _save(filename, hwnd, 5296 + plugin_num, 0, True)

def saveprj(plugin_num, filename, hwnd=None):
    u"""プロジェクトを保存する"""
    _save(filename, hwnd, 1023, 0, True)

def setprof(prof_num, hwnd=None):
    u"""プロファイルを選択する"""
    hwnd = get_aviutl_hwnd(hwnd)
    PostMessage(hwnd, WM_COMMAND, 8006 + prof_num, 0)

def verclose(hwnd=None):
    u"""バージョン情報ダイアログを閉じる（出力を再開する）"""
    hwnd = get_aviutl_hwnd(hwnd)

    hwnds = None
    hwndp = None
    try:
        hwnds = FindWindowEx(None, None, u'#32770', u'バージョン情報')
        hwndp = GetWindowLong(hwnds, GWL_HWNDPARENT)
        while hwndp != hwnd:
            hwnds = FindWindowEx(None, hwnds, u'#32770', u'バージョン情報')
            hwndp = GetWindowLong(hwnds, GWL_HWNDPARENT)
    except WindowsError:
        pass
    if hwnds is None or hwndp != hwnd:
        raise AviUtlError(u'Dialog not found.')
    hwndb = FindWindowEx(hwnds, None, u"Button", u"OK")
    SendMessage(hwndb, WM_LBUTTONDOWN, 0, 0)
    SendMessage(hwndb, WM_LBUTTONUP, 0, 0)

def veropen(hwnd=None):
    u"""バージョン情報ダイアログを開く（出力を中断する）"""
    hwnd = get_aviutl_hwnd(hwnd)
    PostMessage(hwnd, WM_COMMAND, 100, 0)

def wait(hwnd=None):
    u"""AviUtl の出力が終了するまで待つ"""
    hwnd = get_aviutl_hwnd(hwnd)

    hprc = GetCurrentProcess()
    old_process_class = GetPriorityClass(hprc)
    SetPriorityClass(hprc, IDLE_PRIORITY_CLASS)

    buf = create_unicode_buffer(256)
    i = 0
    try:
        while i < 7:
            i += 1
            GetWindowText(hwnd, buf, 256)
            value = buf.value
            if u'出力中' in value or u'検索中' in value:
                time.sleep(5)
                i -= 1
            else:
                time.sleep(0.5)
    finally:
        SetPriorityClass(GetCurrentProcess(), old_process_class)
